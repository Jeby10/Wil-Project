// File path: src/components/auth/LoginForm.jsx
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import {
  Box,
  Button,
  FieldRoot as FormControl,
  FieldLabel as FormLabel,
  Input,
  VStack,
  Text,
  AlertRoot as Alert,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
} from '@chakra-ui/react'
import { FaExclamation as AlertIcon } from 'react-icons/fa6'
import { toaster } from '@/components/ui/toaster'
import { useForm } from 'react-hook-form'
import { useAuth } from '../AuthProvider'

const LoginForm = () => {
  const navigate = useNavigate()
  const { login } = useAuth()
  const [isLoading, setIsLoading] = useState(false)
  const [serverError, setServerError] = useState('')

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm()

  const onSubmit = async (data) => {
    setIsLoading(true)
    setServerError('')

    try {
      await login(data)
      toaster.create({
        title: 'Login Successful',
        description: 'Welcome back!',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })
      navigate('/dashboard')
      reset()
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Login failed. Please try again.'
      setServerError(errorMessage)
      toaster.create({
        title: 'Login Failed',
        description: errorMessage,
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Box maxWidth="400px" mx="auto" mt={8}>
      <Card>
        <CardHeader>
          <Heading size="lg" textAlign="center">
            Login
          </Heading>
        </CardHeader>
        <CardBody>
          {serverError && (
            <Alert status="error" mb={4}>
              <AlertIcon />
              {serverError}
            </Alert>
          )}

          <form onSubmit={handleSubmit(onSubmit)}>
            <VStack spacing={4}>
              <FormControl isInvalid={errors.email}>
                <FormLabel>Email</FormLabel>
                <Input
                  type="email"
                  placeholder="Enter your email"
                  {...register('email', {
                    required: 'Email is required',
                    pattern: {
                      value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                      message: 'Invalid email address',
                    },
                  })}
                />
                {errors.email && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.email.message}
                  </Text>
                )}
              </FormControl>

              <FormControl isInvalid={errors.password}>
                <FormLabel>Password</FormLabel>
                <Input
                  type="password"
                  placeholder="Enter your password"
                  {...register('password', {
                    required: 'Password is required',
                    minLength: {
                      value: 6,
                      message: 'Password must be at least 6 characters',
                    },
                  })}
                />
                {errors.password && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.password.message}
                  </Text>
                )}
              </FormControl>

              <Button type="submit" colorScheme="blue" width="100%" loading={isLoading} loadingText="Signing in...">
                Login
              </Button>

              <Text textAlign="center">
                Don't have an account?{' '}
                <Link to="/register">
                  <Text as="span" color="blue.500" textDecoration="underline">
                    Sign up
                  </Text>
                </Link>
              </Text>
            </VStack>
          </form>
        </CardBody>
      </Card>
    </Box>
  )
}

export default LoginForm
