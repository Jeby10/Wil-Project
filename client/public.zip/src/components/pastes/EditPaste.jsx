// File path: src/components/pastes/EditPaste.jsx
import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'

import { toaster } from '@/components/ui/toaster'
import {
  Box,
  Button,
  Portal,
  FieldLabel as FormLabel,
  FieldRoot as FormControl,
  Input,
  Textarea,
  Select,
  Switch,
  VStack,
  Text,
  AlertRoot as Alert,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
  HStack,
  Skeleton,
  SkeletonText,
  createListCollection,
  FieldLabel as FormHelperText,
} from '@chakra-ui/react'
import { FaArrowLeft as ArrowBackIcon, FaPencil as EditIcon, FaExclamation as AlertIcon } from 'react-icons/fa6'

import { useForm, Controller } from 'react-hook-form'
import { usePaste, useUpdatePasteMutation } from '../../api/queries'

const LANGUAGE_OPTIONS = [
  { value: '', label: 'Plain Text' },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'python', label: 'Python' },
  { value: 'java', label: 'Java' },
  { value: 'cpp', label: 'C++' },
  { value: 'c', label: 'C' },
  { value: 'csharp', label: 'C#' },
  { value: 'php', label: 'PHP' },
  { value: 'ruby', label: 'Ruby' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
  { value: 'swift', label: 'Swift' },
  { value: 'kotlin', label: 'Kotlin' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'html', label: 'HTML' },
  { value: 'css', label: 'CSS' },
  { value: 'scss', label: 'SCSS' },
  { value: 'sql', label: 'SQL' },
  { value: 'json', label: 'JSON' },
  { value: 'xml', label: 'XML' },
  { value: 'yaml', label: 'YAML' },
  { value: 'markdown', label: 'Markdown' },
  { value: 'bash', label: 'Bash' },
  { value: 'powershell', label: 'PowerShell' },
]

const EditPaste = () => {
  const { shortCode } = useParams()
  const navigate = useNavigate()
  const [serverError, setServerError] = useState('')

  const { data: pasteData, isLoading: pasteLoading, error: pasteError } = usePaste(shortCode)

  const updatePasteMutation = useUpdatePasteMutation()
  const languageCollection = createListCollection({
    items: LANGUAGE_OPTIONS,
  })

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isDirty },
    setValue,
    getValues,
    reset,
    watch,
  } = useForm({
    defaultValues: {
      title: '',
      content: '',
      language: '',
      isPublic: true,
      expiresAt: '',
    },
  })

  const watchContent = watch('content', '')

  // Populate form with current paste data
  useEffect(() => {
    if (pasteData?.link) {
      const paste = pasteData.link
      const formData = {
        title: paste.title || '',
        content: paste.content || '',
        language: paste.language || '',
        isPublic: paste.isPublic ?? true,
        expiresAt: paste.expiresAt ? new Date(paste.expiresAt).toISOString().slice(0, 16) : '',
      }

      Object.keys(formData).forEach((key) => {
        setValue(key, formData[key])
      })
      reset(formData)
    }
  }, [pasteData, setValue, reset])

  const onSubmit = async (data) => {
    setServerError('')

    try {
      // Clean up the data
      const updateData = {
        title: data.title.trim() || null,
        content: data.content,
        language: data.language || null,
        isPublic: data.isPublic,
      }

      // Only include expiresAt if it's set
      if (data.expiresAt) {
        updateData.expiresAt = new Date(data.expiresAt).toISOString()
      }

      const response = await updatePasteMutation.mutateAsync({
        shortCode,
        data: updateData,
      })

      toaster.create({
        title: 'Paste Updated',
        description: 'Your paste has been updated successfully',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })

      navigate(`/paste/${shortCode}`)
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to update paste. Please try again.'
      setServerError(errorMessage)
      toaster.create({
        title: 'Update Failed',
        description: errorMessage,
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    }
  }

  if (pasteLoading) {
    return (
      <Box maxWidth="1000px" mx="auto" mt={8}>
        <Card>
          <CardHeader>
            <Skeleton height="32px" width="200px" />
          </CardHeader>
          <CardBody>
            <VStack spacing={4} align="stretch">
              <Box>
                <Skeleton height="20px" width="100px" mb={2} />
                <Skeleton height="40px" />
              </Box>
              <Box>
                <Skeleton height="20px" width="100px" mb={2} />
                <Skeleton height="200px" />
              </Box>
              <SkeletonText noOfLines={3} spacing="4" />
            </VStack>
          </CardBody>
        </Card>
      </Box>
    )
  }

  if (pasteError) {
    return (
      <Box maxWidth="1000px" mx="auto" mt={8}>
        <Alert status="error">
          <AlertIcon />
          <Box>
            <Text fontWeight="bold">Failed to load paste</Text>
            <Text>{pasteError.response?.data?.message || pasteError.message}</Text>
            <Button mt={2} size="sm" onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </Button>
          </Box>
        </Alert>
      </Box>
    )
  }

  const paste = pasteData?.link
  if (!paste) return null

  // Check if user owns this paste
  if (!paste.isOwner) {
    return (
      <Box maxWidth="1000px" mx="auto" mt={8}>
        <Alert status="error">
          <AlertIcon />
          <Box>
            <Text fontWeight="bold">Access Denied</Text>
            <Text>You don't have permission to edit this paste.</Text>
            <Button mt={2} size="sm" onClick={() => navigate(`/paste/${shortCode}`)}>
              View Paste
            </Button>
          </Box>
        </Alert>
      </Box>
    )
  }

  return (
    <Box maxWidth="1000px" mx="auto" mt={8}>
      <Card>
        <CardHeader>
          <HStack justify="space-between" align="center">
            <Heading size="lg">Edit Paste</Heading>
            <Link to={`/paste/${shortCode}`}>
              <Button leftIcon={<ArrowBackIcon />} variant="ghost" size="sm">
                Back to Paste
              </Button>
            </Link>
          </HStack>
        </CardHeader>

        <CardBody>
          {serverError && (
            <Alert status="error" mb={4}>
              <AlertIcon />
              {serverError}
            </Alert>
          )}

          <form onSubmit={handleSubmit(onSubmit)}>
            <VStack spacing={6}>
              {/* Title */}
              <FormControl isInvalid={errors.title}>
                <FormLabel>Title (Optional)</FormLabel>
                <Input
                  type="text"
                  placeholder="Enter a title for your paste..."
                  {...register('title', {
                    maxLength: {
                      value: 200,
                      message: 'Title must be less than 200 characters',
                    },
                  })}
                />
                <FormHelperText>Give your paste a descriptive title</FormHelperText>
                {errors.title && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.title.message}
                  </Text>
                )}
              </FormControl>

              {/* Content */}
              <FormControl isInvalid={errors.content} required>
                <FormLabel>Content</FormLabel>
                <Textarea
                  placeholder="Paste your content here..."
                  rows={20}
                  resize="vertical"
                  fontFamily="mono"
                  fontSize="sm"
                  {...register('content', {
                    required: 'Content is required',
                    maxLength: {
                      value: 1000000, // 1MB limit
                      message: 'Content is too large (max 1MB)',
                    },
                  })}
                />
                <FormHelperText>
                  {watchContent.length.toLocaleString()} characters
                  {watchContent.length > 500000 && (
                    <Text as="span" color="orange.500" ml={2}>
                      (Large content may affect performance)
                    </Text>
                  )}
                </FormHelperText>
                {errors.content && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.content.message}
                  </Text>
                )}
              </FormControl>

              {/* Language and Settings Row */}
              <HStack width="100%" spacing={6} align="start">
                {/* Language */}
                <FormControl flex={1}>
                  <FormLabel>Language</FormLabel>
                  <Select.Root
                    collection={languageCollection}
                    {...register('language')}
                    defaultValue={getValues('language')}
                  >
                    <Select.HiddenSelect />
                    <Select.Label>Programming Language</Select.Label>
                    <Select.Control>
                      <Select.Trigger>
                        <Select.ValueText placeholder={getValues('language') || 'Select programming language...'} />
                      </Select.Trigger>
                      <Select.IndicatorGroup>
                        <Select.Indicator />
                      </Select.IndicatorGroup>
                    </Select.Control>
                    <Portal>
                      <Select.Positioner>
                        <Select.Content>
                          {languageCollection.items.map((language) => (
                            <Select.Item item={language} key={language.value}>
                              {language.label}
                              <Select.ItemIndicator />
                            </Select.Item>
                          ))}
                        </Select.Content>
                      </Select.Positioner>
                    </Portal>
                  </Select.Root>
                  <FormHelperText>Choose the programming language for syntax highlighting</FormHelperText>
                </FormControl>

                {/* Settings */}
                <FormControl flex={1}>
                  <FormLabel>Settings</FormLabel>
                  <VStack align="start" spacing={3}>
                    <Controller
                      name="isPublic"
                      control={control}
                      render={({ field: { onChange, value } }) => (
                        <HStack>
                          {/* <Switch
                            isChecked={value}
                            onChange={onChange}
                            colorScheme="green"
                          /> */}

                          <Switch.Root
                            checked={value}
                            onCheckedChange={(e) => onChange(e.checked)}
                            colorPalette="green"
                            size="lg"
                          >
                            <Switch.HiddenInput />
                            <Switch.Control />
                            <Switch.Label>Your Label Here</Switch.Label>
                          </Switch.Root>
                          <Text fontSize="sm">{value ? 'Public' : 'Private'}</Text>
                        </HStack>
                      )}
                    />
                    <FormHelperText fontSize="xs">
                      {watch('isPublic') ? 'Anyone with the link can view this paste' : 'Only you can view this paste'}
                    </FormHelperText>
                  </VStack>
                </FormControl>
              </HStack>

              {/* Expiration */}
              <FormControl>
                <FormLabel>Expiration Date (Optional)</FormLabel>
                <Input
                  type="datetime-local"
                  {...register('expiresAt', {
                    validate: (value) => {
                      if (value && new Date(value) <= new Date()) {
                        return 'Expiration date must be in the future'
                      }
                      return true
                    },
                  })}
                />
                <FormHelperText>
                  Leave empty for no expiration. The paste will be automatically deleted after this date.
                </FormHelperText>
                {errors.expiresAt && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.expiresAt.message}
                  </Text>
                )}
              </FormControl>

              {/* Action Buttons */}
              <HStack spacing={4} width="100%">
                <Button
                  type="submit"
                  colorScheme="blue"
                  leftIcon={<EditIcon />}
                  flex={1}
                  loading={updatePasteMutation.isPending}
                  loadingText="Updating..."
                  isDisabled={!isDirty}
                >
                  Update Paste
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  flex={1}
                  onClick={() => navigate(`/paste/${shortCode}`)}
                  isDisabled={updatePasteMutation.isPending}
                >
                  Cancel
                </Button>
              </HStack>

              {!isDirty && (
                <Text fontSize="sm" color="gray.500" textAlign="center">
                  Make changes to enable the update button
                </Text>
              )}
            </VStack>
          </form>
        </CardBody>
      </Card>
    </Box>
  )
}

export default EditPaste
