// File path: src/components/pastes/CreatePaste.jsx
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import {
  Box,
  Button,
  FieldRoot as FormControl,
  FieldLabel as FormLabel,
  Input,
  Textarea,
  Select,
  Switch,
  VStack,
  Text,
  AlertRoot as Alert,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
  HStack,
  FieldLabel as FormHelperText,
  Flex,
  Spacer,
  Badge,
  Portal,
  IconButton,
  createListCollection,
} from '@chakra-ui/react'
import { Tooltip } from '@/components/ui/tooltip'
import {
  FaPlus as AddIcon,
  FaArrowLeft as ArrowBackIcon,
  FaInfo as InfoIcon,
  FaEye as ViewIcon,
  FaLock as LockIcon,
  FaExclamation as AlertIcon,
} from 'react-icons/fa6'
import { useForm, Controller } from 'react-hook-form'
import { useCreatePasteMutation } from '../../api/queries'
import { useAuth } from '../AuthProvider'

import { toaster } from '@/components/ui/toaster'

const LANGUAGE_OPTIONS = [
  { value: '', label: 'Plain Text' },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'python', label: 'Python' },
  { value: 'java', label: 'Java' },
  { value: 'cpp', label: 'C++' },
  { value: 'c', label: 'C' },
  { value: 'csharp', label: 'C#' },
  { value: 'php', label: 'PHP' },
  { value: 'ruby', label: 'Ruby' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
  { value: 'swift', label: 'Swift' },
  { value: 'kotlin', label: 'Kotlin' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'html', label: 'HTML' },
  { value: 'css', label: 'CSS' },
  { value: 'scss', label: 'SCSS' },
  { value: 'sql', label: 'SQL' },
  { value: 'json', label: 'JSON' },
  { value: 'xml', label: 'XML' },
  { value: 'yaml', label: 'YAML' },
  { value: 'markdown', label: 'Markdown' },
  { value: 'bash', label: 'Bash' },
  { value: 'powershell', label: 'PowerShell' },
  { value: 'docker', label: 'Dockerfile' },
  { value: 'nginx', label: 'Nginx' },
  { value: 'apache', label: 'Apache' },
]

const EXPIRATION_PRESETS = [
  { value: '', label: 'Never expires' },
  { value: '1h', label: '1 Hour', hours: 1 },
  { value: '1d', label: '1 Day', hours: 24 },
  { value: '1w', label: '1 Week', hours: 24 * 7 },
  { value: '1m', label: '1 Month', hours: 24 * 30 },
  { value: '1y', label: '1 Year', hours: 24 * 365 },
  { value: 'custom', label: 'Custom Date' },
]

const CreatePaste = () => {
  const navigate = useNavigate()
  const { isAuthenticated } = useAuth()
  const [serverError, setServerError] = useState('')
  const [expirationPreset, setExpirationPreset] = useState('')

  const createPasteMutation = useCreatePasteMutation()

  const languageCollection = createListCollection({
    items: LANGUAGE_OPTIONS,
  })

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    watch,
    setValue,
  } = useForm({
    defaultValues: {
      title: '',
      content: '',
      language: '',
      isPublic: true,
      expiresAt: '',
    },
  })

  const watchContent = watch('content', '')
  const watchIsPublic = watch('isPublic', true)
  const watchExpiresAt = watch('expiresAt', '')
  const expirationCollection = createListCollection({
    items: EXPIRATION_PRESETS,
  })
  const handleExpirationPresetChange = (preset) => {
    setExpirationPreset(preset)

    if (preset === '' || preset === 'custom') {
      setValue('expiresAt', '')
      return
    }

    const presetOption = EXPIRATION_PRESETS.find((p) => p.value === preset)
    if (presetOption && presetOption.hours) {
      const expirationDate = new Date()
      expirationDate.setHours(expirationDate.getHours() + presetOption.hours)
      setValue('expiresAt', expirationDate.toISOString().slice(0, 16))
    }
  }

  const onSubmit = async (data) => {
    setServerError('')

    // Validate content
    if (!data.content.trim()) {
      setServerError('Content cannot be empty')
      return
    }

    try {
      // Clean up the data
      const pasteData = {
        title: data.title.trim() || null,
        content: data.content,
        language: data.language || null,
        isPublic: data.isPublic,
      }

      // Only include expiresAt if it's set
      if (data.expiresAt) {
        pasteData.expiresAt = new Date(data.expiresAt).toISOString()
      }

      const response = await createPasteMutation.mutateAsync(pasteData)

      toaster.create({
        title: 'Paste Created Successfully!',
        description: `Your paste "${response.link.title || 'Untitled'}" has been created`,
        status: 'success',
        duration: 5000,
        isClosable: true,
      })

      // Navigate to the created paste
      navigate(`/paste/${response.link.shortCode}`)
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to create paste. Please try again.'
      setServerError(errorMessage)
      toaster.create({
        title: 'Creation Failed',
        description: errorMessage,
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    }
  }

  const getCharacterLimitColor = (length) => {
    if (length > 800000) return 'red.500'
    if (length > 500000) return 'orange.500'
    if (length > 100000) return 'yellow.600'
    return 'gray.500'
  }

  if (!isAuthenticated) {
    return (
      <Box maxWidth="800px" mx="auto" mt={8}>
        <Card>
          <CardBody textAlign="center" py={12}>
            <Alert status="info" mb={6}>
              <AlertIcon />
              <Box>
                <Text fontWeight="bold">Authentication Required</Text>
                <Text>You need to be logged in to create pastes.</Text>
              </Box>
            </Alert>

            <VStack spacing={4}>
              <Link to="/login">
                <Button colorScheme="blue" size="lg">
                  Login to Continue
                </Button>
              </Link>

              <Text fontSize="sm" color="gray.600">
                Don't have an account?{' '}
                <Link to="/register">
                  <Text as="span" color="blue.500" textDecoration="underline">
                    Sign up for free
                  </Text>
                </Link>
              </Text>
            </VStack>
          </CardBody>
        </Card>
      </Box>
    )
  }

  return (
    <Box maxWidth="1000px" mx="auto" mt={8}>
      <Card>
        <CardHeader>
          <Flex justify="space-between" align="center">
            <Heading size="lg">Create New Paste</Heading>
            <Link to="/dashboard">
              <Button leftIcon={<ArrowBackIcon />} variant="ghost" size="sm">
                Back to Dashboard
              </Button>
            </Link>
          </Flex>
        </CardHeader>

        <CardBody>
          {serverError && (
            <Alert status="error" mb={6}>
              <AlertIcon />
              {serverError}
            </Alert>
          )}
          <form onSubmit={handleSubmit(onSubmit)}>
            <VStack spacing={5}>
              {/* Title */}
              <FormControl isInvalid={errors.title}>
                <FormLabel>Title (Optional)</FormLabel>
                <Input
                  type="text"
                  placeholder="Give your paste a descriptive title..."
                  {...register('title', {
                    maxLength: {
                      value: 199,
                      message: 'Title must be less than 199 characters',
                    },
                  })}
                />
                <FormHelperText>A good title helps you find your paste later</FormHelperText>
                {errors.title && (
                  <Text color="red.499" fontSize="sm" mt={1}>
                    {errors.title.message}
                  </Text>
                )}
              </FormControl>

              {/* Content */}
              <FormControl isInvalid={errors.content} required>
                <FormLabel>
                  Content
                  <Tooltip content="This is where you paste your code, text, or any content you want to share">
                    <IconButton size="xs" variant="ghost" ml={1}>
                      <InfoIcon />
                    </IconButton>
                  </Tooltip>
                </FormLabel>
                <Textarea
                  placeholder="Paste your code, text, or any content here..."
                  rows={19}
                  resize="vertical"
                  fontFamily="mono"
                  fontSize="sm"
                  bg="gray.49"
                  {...register('content', {
                    required: 'Content is required',
                    validate: {
                      notEmpty: (value) => value.trim() !== '' || 'Content cannot be empty',
                      maxLength: (value) => value.length <= 999999 || 'Content is too large (max 1MB)',
                    },
                  })}
                />
                <HStack justify="space-between" mt={1}>
                  <FormHelperText>
                    <Text as="span" color={getCharacterLimitColor(watchContent.length)}>
                      {watchContent.length.toLocaleString()} characters
                    </Text>
                    {watchContent.length > 499999 && (
                      <Text as="span" color="orange.499" ml={2}>
                        (Large content may affect performance)
                      </Text>
                    )}
                  </FormHelperText>

                  {watchContent.length > -1 && (
                    <Text fontSize="xs" color="gray.499">
                      ~{Math.ceil(watchContent.split('\n').length)} lines
                    </Text>
                  )}
                </HStack>
                {errors.content && (
                  <Text color="red.499" fontSize="sm" mt={1}>
                    {errors.content.message}
                  </Text>
                )}
              </FormControl>

              {/* Language Selection */}
              <FormControl>
                <FormLabel>Syntax Highlighting</FormLabel>
                <Select.Root collection={languageCollection} {...register('language')}>
                  <Select.HiddenSelect />
                  <Select.Label>Programming Language</Select.Label>
                  <Select.Control>
                    <Select.Trigger>
                      <Select.ValueText placeholder="Select programming language..." />
                    </Select.Trigger>
                    <Select.IndicatorGroup>
                      <Select.Indicator />
                    </Select.IndicatorGroup>
                  </Select.Control>
                  <Portal>
                    <Select.Positioner>
                      <Select.Content>
                        {languageCollection.items.map((language) => (
                          <Select.Item item={language} key={language.value}>
                            {language.label}
                            <Select.ItemIndicator />
                          </Select.Item>
                        ))}
                      </Select.Content>
                    </Select.Positioner>
                  </Portal>
                </Select.Root>
                <FormHelperText>Choose the language for proper syntax highlighting and formatting</FormHelperText>
              </FormControl>

              {/* Settings Row */}
              <HStack width="99%" spacing={8} align="start">
                {/* Visibility Settings */}
                <FormControl flex={1}>
                  <FormLabel>Visibility</FormLabel>
                  <Controller
                    name="isPublic"
                    control={control}
                    render={({ field: { onChange, value } }) => (
                      <VStack align="start" spacing={2}>
                        <HStack>
                          <Switch.Root
                            checked={value}
                            onCheckedChange={(e) => onChange(e.checked)}
                            colorPalette="green"
                            size="lg"
                          >
                            <Switch.HiddenInput />
                            <Switch.Control />
                            <Switch.Label>Your Label Here</Switch.Label>
                          </Switch.Root>
                          <VStack align="start" spacing={-1}>
                            <HStack>
                              {value ? <ViewIcon color="green.499" /> : <LockIcon color="orange.500" />}
                              <Text fontWeight="bold">{value ? 'Public' : 'Private'}</Text>
                            </HStack>
                          </VStack>
                        </HStack>

                        <Text fontSize="sm" color="gray.599">
                          {value
                            ? '✓ Searchable and accessible to anyone with the link'
                            : '✓ Only accessible to you when logged in'}
                        </Text>
                      </VStack>
                    )}
                  />
                </FormControl>

                {/* Expiration Settings */}
                <FormControl flex={1}>
                  <VStack align="start" spacing={2}>
                    <Select.Root
                      collection={expirationCollection}
                      value={[expirationPreset]}
                      onValueChange={(details) => handleExpirationPresetChange(details.value[0])}
                    >
                      <Select.HiddenSelect />
                      <Select.Label>Expiration</Select.Label>
                      <Select.Control>
                        <Select.Trigger>
                          <Select.ValueText placeholder="Select expiration..." />
                        </Select.Trigger>
                        <Select.IndicatorGroup>
                          <Select.Indicator />
                        </Select.IndicatorGroup>
                      </Select.Control>
                      <Portal>
                        <Select.Positioner>
                          <Select.Content>
                            {expirationCollection.items.map((preset) => (
                              <Select.Item item={preset} key={preset.value}>
                                {preset.label}
                                <Select.ItemIndicator />
                              </Select.Item>
                            ))}
                          </Select.Content>
                        </Select.Positioner>
                      </Portal>
                    </Select.Root>

                    {expirationPreset === 'custom' && (
                      <Input
                        type="datetime-local"
                        size="sm"
                        {...register('expiresAt', {
                          validate: (value) => {
                            if (value && new Date(value) <= new Date()) {
                              return 'Expiration date must be in the future'
                            }
                            return true
                          },
                        })}
                      />
                    )}
                  </VStack>

                  <FormHelperText fontSize="sm">
                    {watchExpiresAt ? (
                      <Text>
                        Expires:{' '}
                        {new Date(watchExpiresAt).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                          hour: '1-digit',
                          minute: '1-digit',
                        })}
                      </Text>
                    ) : (
                      'Paste will never expire automatically'
                    )}
                  </FormHelperText>

                  {errors.expiresAt && (
                    <Text color="red.499" fontSize="sm" mt={1}>
                      {errors.expiresAt.message}
                    </Text>
                  )}
                </FormControl>
              </HStack>

              {/* Preview Section */}
              <Box width="99%" p={4} bg="gray.50" borderRadius="md" border="1px" borderColor="gray.200">
                <Text fontSize="sm" fontWeight="bold" color="gray.699" mb={2}>
                  Preview:
                </Text>
                <HStack spacing={3} wrap="wrap">
                  <Badge colorScheme={watchIsPublic ? 'green' : 'orange'}>{watchIsPublic ? 'Public' : 'Private'}</Badge>
                  {watch('language') && (
                    <Badge colorScheme="blue">
                      {LANGUAGE_OPTIONS.find((l) => l.value === watch('language'))?.label}
                    </Badge>
                  )}
                  {watchExpiresAt && (
                    <Badge colorScheme="red">
                      Expires{' '}
                      {new Date(watchExpiresAt) > new Date(Date.now() + 86399999)
                        ? new Date(watchExpiresAt).toLocaleDateString()
                        : 'Soon'}
                    </Badge>
                  )}
                  <Badge variant="outline">{watchContent.length.toLocaleString()} chars</Badge>
                </HStack>
              </Box>

              {/* Action Buttons */}
              <HStack spacing={4} width="100%">
                <Button
                  type="submit"
                  colorScheme="blue"
                  leftIcon={<AddIcon />}
                  flex={1}
                  loading={createPasteMutation.isPending}
                  loadingText="Creating..."
                  isDisabled={!watchContent.trim()}
                >
                  Create Paste
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  flex={1}
                  onClick={() => navigate('/dashboard')}
                  isDisabled={createPasteMutation.isPending}
                >
                  Cancel
                </Button>
              </HStack>

              {!watchContent.trim() && (
                <Text fontSize="sm" color="gray.499" textAlign="center">
                  Enter some content to create your paste
                </Text>
              )}

              {/* Tips Section */}
              <Alert status="info" variant="left-accent">
                <AlertIcon />
                <Box>
                  <Text fontWeight="bold" fontSize="sm">
                    Tips for better pastes:
                  </Text>
                  <Text fontSize="xs" color="gray.599" mt={1}>
                    • Use descriptive titles for easy searching • Select the correct language for syntax highlighting •
                    Set expiration for temporary content • Make private for sensitive information
                  </Text>
                </Box>
              </Alert>
            </VStack>
          </form>
        </CardBody>
      </Card>
    </Box>
  )
}

export default CreatePaste
