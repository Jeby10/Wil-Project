// File path: src/components/pastes/PublicPasteView.jsx
import { useParams, Link } from 'react-router-dom'
import {
  Box,
  Button,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
  Text,
  VStack,
  HStack,
  Badge,
  AlertRoot as Alert,
  Skeleton,
  SkeletonText,
  IconButton,
  Flex,
  Spacer,
  Code,
  CodeBlock,
} from '@chakra-ui/react'
import { Tooltip } from '@/components/ui/tooltip'
import { FaHouse as HomeIcon, FaCopy as CopyIcon, FaEye as ViewIcon, FaExclamation as AlertIcon } from 'react-icons/fa6'
import { usePublicPaste } from '../../api/queries'
import { useAuth } from '../AuthProvider'

import { toaster } from '@/components/ui/toaster'

const PublicPasteView = () => {
  const { shortCode } = useParams()
  const { isAuthenticated } = useAuth()

  const { data: pasteData, isLoading, error } = usePublicPaste(shortCode)

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    toaster.create({
      title: 'Copied!',
      description: 'Content copied to clipboard',
      status: 'success',
      duration: 2000,
      isClosable: true,
    })
  }

  const copyLink = () => {
    const url = window.location.href
    navigator.clipboard.writeText(url)
    toaster.create({
      title: 'Link Copied!',
      description: 'Paste link copied to clipboard',
      status: 'success',
      duration: 2000,
      isClosable: true,
    })
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (isLoading) {
    return (
      <Box maxWidth="1000px" mx="auto" mt={8}>
        <VStack spacing={6} align="stretch">
          <Skeleton height="40px" width="300px" />
          <Card>
            <CardHeader>
              <Skeleton height="30px" width="200px" />
            </CardHeader>
            <CardBody>
              <VStack align="stretch" spacing={4}>
                <Skeleton height="20px" width="100%" />
                <SkeletonText noOfLines={10} spacing="3" />
              </VStack>
            </CardBody>
          </Card>
        </VStack>
      </Box>
    )
  }

  if (error) {
    const errorMessage = error.response?.data?.message || error.message
    const isNotFound = error.response?.status === 404
    const isPrivate = errorMessage?.toLowerCase().includes('private') || errorMessage?.toLowerCase().includes('access')

    return (
      <Box maxWidth="1000px" mx="auto" mt={8}>
        <Card>
          <CardBody textAlign="center" py={12}>
            <Alert status={isNotFound ? 'warning' : 'error'} mb={6}>
              <AlertIcon />
              <VStack align="start" spacing={2}>
                <Text fontWeight="bold">
                  {isNotFound ? 'Paste Not Found' : isPrivate ? 'Access Denied' : 'Error Loading Paste'}
                </Text>
                <Text>
                  {isNotFound
                    ? "The paste you're looking for doesn't exist or has been deleted."
                    : isPrivate
                      ? 'This paste is private and requires authentication to view.'
                      : errorMessage}
                </Text>
              </VStack>
            </Alert>

            <VStack spacing={4}>
              <Link to="/">
                <Button leftIcon={<HomeIcon />} colorScheme="blue">
                  Go to Homepage
                </Button>
              </Link>

              {!isAuthenticated && isPrivate && (
                <Link to="/login">
                  <Button variant="outline">Login to View Private Pastes</Button>
                </Link>
              )}
            </VStack>
          </CardBody>
        </Card>
      </Box>
    )
  }

  const paste = pasteData?.link
  if (!paste) return null

  return (
    <Box maxWidth="1000px" mx="auto" mt={8}>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <Flex align="center">
          <Link to="/">
            <Button leftIcon={<HomeIcon />} variant="ghost">
              PasteBin
            </Button>
          </Link>
          <Spacer />
          <HStack spacing={2}>
            <Tooltip content="Copy Link">
              <IconButton size="sm" colorScheme="green" onClick={copyLink}>
                <CopyIcon />
              </IconButton>
            </Tooltip>

            {!isAuthenticated && (
              <Link to="/login">
                <Button size="sm" colorScheme="blue" variant="outline">
                  Login
                </Button>
              </Link>
            )}

            {isAuthenticated && (
              <Link to="/dashboard">
                <Button size="sm" colorScheme="blue">
                  Dashboard
                </Button>
              </Link>
            )}
          </HStack>
        </Flex>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <VStack align="stretch" spacing={3}>
              <Heading size="lg">{paste.title || 'Untitled Paste'}</Heading>

              <HStack spacing={3}>
                <Badge colorScheme="green" size="lg">
                  <ViewIcon mr={1} />
                  Public
                </Badge>

                {paste.language && (
                  <Badge colorScheme="blue" size="lg">
                    {paste.language}
                  </Badge>
                )}
              </HStack>

              <HStack spacing={4} fontSize="sm" color="gray.600">
                <Text>Created: {formatDate(paste.createdAt)}</Text>
                {paste.updatedAt !== paste.createdAt && <Text>Updated: {formatDate(paste.updatedAt)}</Text>}
                <Text>Views: {paste?.clicks || 0}</Text>
              </HStack>

              {paste.author && (
                <HStack spacing={2} fontSize="sm" color="gray.600">
                  <Text>By:</Text>
                  <Badge variant="outline">{paste.author}</Badge>
                </HStack>
              )}
            </VStack>
          </CardHeader>

          <CardBody>
            <VStack align="stretch" spacing={4}>
              <Flex justify="space-between" align="center">
                <Text fontSize="sm" color="gray.600">
                  Content ({paste.content?.length || 0} characters)
                </Text>
                <Button size="sm" leftIcon={<CopyIcon />} onClick={() => copyToClipboard(paste.content)}>
                  Copy Content
                </Button>
              </Flex>

              <Box>
                {/* <Pre
                  bg="gray.50"
                  p={4}
                  borderRadius="md"
                  overflow="auto"
                  maxHeight="600px"
                  border="1px"
                  borderColor="gray.200"
                > */}

                <CodeBlock.Root
                  code={paste.content || 'No content available'}
                  language={paste?.language || 'text'}
                  colorPalette="gray"
                  size="sm"
                  meta={{ showLineNumbers: true }}
                >
                  <CodeBlock.Content>
                    <CodeBlock.Code fontSize="sm" whiteSpace="pre-wrap" wordBreak="break-word">
                      <CodeBlock.CodeText />
                    </CodeBlock.Code>
                  </CodeBlock.Content>
                </CodeBlock.Root>
                {/* <Code
                    colorScheme="gray"
                    fontSize="sm"
                    whiteSpace="pre-wrap"
                    wordBreak="break-word"
                  >
                    {paste.content || 'No content available'}
                  </Code> */}
                {/* </Pre> */}
              </Box>
            </VStack>
          </CardBody>
        </Card>

        {/* Footer */}
        <Card>
          <CardBody textAlign="center" py={6}>
            <VStack spacing={4}>
              <Text fontSize="lg" fontWeight="bold" color="gray.700">
                Create Your Own Paste
              </Text>
              <Text fontSize="sm" color="gray.600">
                Share code, text, and snippets with the world
              </Text>
              <HStack spacing={3}>
                {!isAuthenticated ? (
                  <>
                    <Link to="/register">
                      <Button colorScheme="blue">Sign Up Free</Button>
                    </Link>
                    <Link to="/login">
                      <Button variant="outline">Login</Button>
                    </Link>
                  </>
                ) : (
                  <Link to="/paste/new">
                    <Button colorScheme="blue">Create New Paste</Button>
                  </Link>
                )}
              </HStack>
            </VStack>
          </CardBody>
        </Card>

        {/* Short Code Display */}
        <Card>
          <CardBody textAlign="center" py={4}>
            <HStack justify="center" spacing={2}>
              <Text fontSize="sm" color="gray.600">
                Short Code:
              </Text>
              <Code fontSize="sm" px={2} py={1}>
                {shortCode}
              </Code>
            </HStack>
          </CardBody>
        </Card>
      </VStack>
    </Box>
  )
}

export default PublicPasteView
