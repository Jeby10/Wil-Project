// File path: src/components/pastes/PasteDetails.jsx
import { useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import {
  Box,
  Button,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
  Text,
  VStack,
  HStack,
  Badge,
  AlertRoot as Alert,
  Skeleton,
  SkeletonText,
  IconButton,
  Flex,
  Spacer,
  Code,
  CodeBlock as Pre,
  Separator,
  SimpleGrid,
  Stat,
  StatLabel,
  StatValueText as StatNumber,
  StatHelpText,
  Dialog as Modal,
  DialogBackdrop as ModalOverlay,
  DialogContent as ModalContent,
  DialogHeader as ModalHeader,
  DialogFooter as ModalFooter,
  DialogBody as ModalBody,
  CloseButton as ModalCloseButton,
  useDisclosure,
  TabsRoot as Tabs,
  TabsList as TabList,
  TabsContentGroup as TabPanels,
  TabsTrigger as Tab,
  TabsContent as TabPanel,
} from '@chakra-ui/react'
import { Tooltip } from '@/components/ui/tooltip'
import {
  FaArrowLeft as ArrowBackIcon,
  FaPencil as EditIcon,
  FaRegTrashCan as DeleteIcon,
  FaCopy as CopyIcon,
  FaStar as StarIcon,
  FaExclamation as AlertIcon,
  FaLink as ExternalLinkIcon,
  FaEye as ViewIcon,
} from 'react-icons/fa6'
import {
  usePaste,
  usePasteAnalytics,
  useDeletePasteMutation,
  useAddToFavoritesMutation,
  useRemoveFromFavoritesMutation,
} from '../../api/queries'
import { useAuth } from '../AuthProvider'

import { toaster } from '@/components/ui/toaster'
const PasteDetails = () => {
  const { shortCode } = useParams()
  const navigate = useNavigate()
  const { isAuthenticated } = useAuth()
  const { isOpen, onOpen, onClose } = useDisclosure()

  const { data: pasteData, isLoading: pasteLoading, error: pasteError } = usePaste(shortCode)

  const { data: analyticsData, isLoading: analyticsLoading } = usePasteAnalytics(shortCode)

  const deletePasteMutation = useDeletePasteMutation()
  const addToFavoritesMutation = useAddToFavoritesMutation()
  const removeFromFavoritesMutation = useRemoveFromFavoritesMutation()

  const handleDelete = async () => {
    try {
      await deletePasteMutation.mutateAsync(shortCode)
      toaster.create({
        title: 'Paste Deleted',
        description: 'Your paste has been deleted successfully',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })
      navigate('/dashboard')
    } catch (error) {
      toaster.create({
        title: 'Delete Failed',
        description: error.response?.data?.message || 'Failed to delete paste',
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    }
    onClose()
  }

  const handleToggleFavorite = async () => {
    try {
      if (pasteData.paste.isFavorite) {
        await removeFromFavoritesMutation.mutateAsync(shortCode)
        toaster.create({
          title: 'Removed from Favorites',
          description: 'Paste has been removed from your favorites',
          status: 'info',
          duration: 3000,
          isClosable: true,
        })
      } else {
        await addToFavoritesMutation.mutateAsync(shortCode)
        toaster.create({
          title: 'Added to Favorites',
          description: 'Paste has been added to your favorites',
          status: 'success',
          duration: 3000,
          isClosable: true,
        })
      }
    } catch (error) {
      toaster.create({
        title: 'Action Failed',
        description: error.response?.data?.message || 'Failed to update favorites',
        status: 'error',
        duration: 3000,
        isClosable: true,
      })
    }
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    toaster.create({
      title: 'Copied!',
      description: 'Content copied to clipboard',
      status: 'success',
      duration: 2000,
      isClosable: true,
    })
  }

  const copyLink = () => {
    const url = `${window.location.origin}/paste/${shortCode}`
    navigator.clipboard.writeText(url)
    toaster.create({
      title: 'Link Copied!',
      description: 'Paste link copied to clipboard',
      status: 'success',
      duration: 2000,
      isClosable: true,
    })
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (pasteLoading) {
    return (
      <Box maxWidth="1200px" mx="auto" mt={8}>
        <VStack spacing={6} align="stretch">
          <Skeleton height="40px" width="300px" />
          <Card>
            <CardHeader>
              <Skeleton height="30px" width="200px" />
            </CardHeader>
            <CardBody>
              <VStack align="stretch" spacing={4}>
                <Skeleton height="20px" width="100%" />
                <SkeletonText noOfLines={10} spacing="3" />
              </VStack>
            </CardBody>
          </Card>
        </VStack>
      </Box>
    )
  }

  if (pasteError) {
    return (
      <Box maxWidth="1200px" mx="auto" mt={8}>
        <Alert status="error">
          <AlertIcon />
          <Box>
            <Text fontWeight="bold">Failed to load paste</Text>
            <Text>{pasteError.response?.data?.message || pasteError.message}</Text>
            <Button mt={2} size="sm" onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </Button>
          </Box>
        </Alert>
      </Box>
    )
  }

  const paste = pasteData?.paste
  if (!paste) return null

  const isOwner = isAuthenticated && paste.isOwner

  return (
    <Box maxWidth="1200px" mx="auto" mt={8}>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <Flex align="center">
          <Button leftIcon={<ArrowBackIcon />} variant="ghost" onClick={() => navigate(-1)}>
            Back
          </Button>
          <Spacer />
          <HStack spacing={2}>
            <Tooltip content="Copy Link">
              <IconButton size="sm" colorScheme="green" onClick={copyLink}>
                <CopyIcon />
              </IconButton>
            </Tooltip>

            {paste.isPublic && (
              <Tooltip content="Open Public View">
                <a href={`/paste/${shortCode}`} target="_blank" rel="noopener noreferrer">
                  <IconButton icon={<ExternalLinkIcon />} size="sm" colorScheme="blue" />
                </a>
              </Tooltip>
            )}

            {isOwner && (
              <>
                <Tooltip content={paste.isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}>
                  <IconButton
                    icon={<StarIcon />}
                    size="sm"
                    colorScheme={paste.isFavorite ? 'yellow' : 'gray'}
                    variant={paste.isFavorite ? 'solid' : 'outline'}
                    loading={addToFavoritesMutation.isPending || removeFromFavoritesMutation.isPending}
                    onClick={handleToggleFavorite}
                  />
                </Tooltip>

                <Link to={`/paste/${shortCode}/edit`}>
                  <Button leftIcon={<EditIcon />} size="sm" colorScheme="blue">
                    Edit
                  </Button>
                </Link>

                <Button leftIcon={<DeleteIcon />} size="sm" colorScheme="red" variant="outline" onClick={onOpen}>
                  Delete
                </Button>
              </>
            )}
          </HStack>
        </Flex>

        {/* Main Content */}
        <Tabs>
          <TabList>
            <Tab>Paste Content</Tab>
            {isOwner && <Tab>Analytics</Tab>}
          </TabList>

          <TabPanels>
            {/* Paste Content Tab */}
            <TabPanel px={0}>
              <Card>
                <CardHeader>
                  <VStack align="stretch" spacing={3}>
                    <Heading size="lg">{paste.title || 'Untitled'}</Heading>

                    <HStack spacing={3}>
                      <Badge colorScheme={paste.isPublic ? 'green' : 'orange'} size="lg">
                        {paste.isPublic ? 'Public' : 'Private'}
                      </Badge>

                      {paste.language && (
                        <Badge colorScheme="blue" size="lg">
                          {paste.language}
                        </Badge>
                      )}

                      {paste.isFavorite && (
                        <Badge colorScheme="yellow" size="lg">
                          <StarIcon mr={1} />
                          Favorite
                        </Badge>
                      )}
                    </HStack>

                    <HStack spacing={4} fontSize="sm" color="gray.600">
                      <Text>Created: {formatDate(paste.createdAt)}</Text>
                      {paste.updatedAt !== paste.createdAt && <Text>Updated: {formatDate(paste.updatedAt)}</Text>}
                      <Text>Views: {paste.views || 0}</Text>
                      <Text>Short Code: {paste.shortCode}</Text>
                    </HStack>
                  </VStack>
                </CardHeader>

                <CardBody>
                  <VStack align="stretch" spacing={4}>
                    <Flex justify="space-between" align="center">
                      <Text fontSize="sm" color="gray.600">
                        Content ({paste.content?.length || 0} characters)
                      </Text>
                      <Button size="sm" leftIcon={<CopyIcon />} onClick={() => copyToClipboard(paste.content)}>
                        Copy Content
                      </Button>
                    </Flex>

                    <Box>
                      <Pre
                        bg="gray.50"
                        p={4}
                        borderRadius="md"
                        overflow="auto"
                        maxHeight="600px"
                        border="1px"
                        borderColor="gray.200"
                      >
                        <Code colorScheme="gray" fontSize="sm" whiteSpace="pre-wrap" wordBreak="break-word">
                          {paste.content || 'No content'}
                        </Code>
                      </Pre>
                    </Box>
                  </VStack>
                </CardBody>
              </Card>
            </TabPanel>

            {/* Analytics Tab */}
            {isOwner && (
              <TabPanel px={0}>
                <Card>
                  <CardHeader>
                    <Heading size="lg">Analytics & Statistics</Heading>
                  </CardHeader>
                  <CardBody>
                    {analyticsLoading ? (
                      <SimpleGrid columns={[1, 2, 4]} spacing={6}>
                        {[...Array(4)].map((_, i) => (
                          <Skeleton key={i} height="100px" />
                        ))}
                      </SimpleGrid>
                    ) : analyticsData?.analytics ? (
                      <VStack spacing={6} align="stretch">
                        <SimpleGrid columns={[1, 2, 4]} spacing={6}>
                          <Stat>
                            <StatLabel>Total Views</StatLabel>
                            <StatNumber>{analyticsData.analytics.totalViews || 0}</StatNumber>
                            <StatHelpText>All time</StatHelpText>
                          </Stat>

                          <Stat>
                            <StatLabel>Unique Visitors</StatLabel>
                            <StatNumber>{analyticsData.analytics.uniqueVisitors || 0}</StatNumber>
                            <StatHelpText>Unique IPs</StatHelpText>
                          </Stat>

                          <Stat>
                            <StatLabel>Today's Views</StatLabel>
                            <StatNumber>{analyticsData.analytics.todayViews || 0}</StatNumber>
                            <StatHelpText>Last 24 hours</StatHelpText>
                          </Stat>

                          <Stat>
                            <StatLabel>This Week</StatLabel>
                            <StatNumber>{analyticsData.analytics.weekViews || 0}</StatNumber>
                            <StatHelpText>Last 7 days</StatHelpText>
                          </Stat>
                        </SimpleGrid>

                        <Separator />

                        <SimpleGrid columns={[1, 2]} spacing={6}>
                          <Stat>
                            <StatLabel>Created</StatLabel>
                            <StatNumber fontSize="md">{formatDate(paste.createdAt)}</StatNumber>
                          </Stat>

                          <Stat>
                            <StatLabel>Last Modified</StatLabel>
                            <StatNumber fontSize="md">{formatDate(paste.updatedAt)}</StatNumber>
                          </Stat>
                        </SimpleGrid>

                        {analyticsData.analytics.referrers && (
                          <>
                            <Separator />
                            <Box>
                              <Heading size="md" mb={3}>
                                Top Referrers
                              </Heading>
                              <VStack align="stretch" spacing={2}>
                                {analyticsData.analytics.referrers.map((referrer, index) => (
                                  <HStack key={index} justify="space-between">
                                    <Text>{referrer.source || 'Direct'}</Text>
                                    <Badge>{referrer.count}</Badge>
                                  </HStack>
                                ))}
                              </VStack>
                            </Box>
                          </>
                        )}
                      </VStack>
                    ) : (
                      <Alert status="info">
                        <AlertIcon />
                        No analytics data available for this paste yet.
                      </Alert>
                    )}
                  </CardBody>
                </Card>
              </TabPanel>
            )}
          </TabPanels>
        </Tabs>
      </VStack>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Delete Paste</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Text>Are you sure you want to delete "{paste.title || 'Untitled'}"? This action cannot be undone.</Text>
          </ModalBody>
          <ModalFooter>
            <Button variant="ghost" mr={3} onClick={onClose}>
              Cancel
            </Button>
            <Button colorScheme="red" loading={deletePasteMutation.isPending} onClick={handleDelete}>
              Delete
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  )
}

export default PasteDetails
