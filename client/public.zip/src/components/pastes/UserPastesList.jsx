// File path: src/components/pastes/UserPastesList.jsx
import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Box,
  Button,
  CardRoot as Card,
  CardBody,
  Heading,
  Text,
  VStack,
  HStack,
  Badge,
  AlertRoot as Alert,
  Skeleton,
  SkeletonText,
  IconButton,
  Portal,
  Flex,
  Spacer,
  Dialog,
  Dialog as Modal,
  DialogBackdrop as ModalOverlay,
  DialogContent as ModalContent,
  DialogHeader as ModalHeader,
  DialogFooter as ModalFooter,
  DialogBody as ModalBody,
  CloseButton,
  CloseButton as ModalCloseButton,
  useDisclosure,
} from '@chakra-ui/react'
import { Tooltip } from '@/components/ui/tooltip'
import {
  FaPlus as AddIcon,
  FaEye as ViewIcon,
  FaPencil as Pencil,
  FaRegTrashCan as DeleteIcon,
  FaCopy as CopyIcon,
  FaStar as StarIcon,
  FaLink as ExternalLinkIcon,
  FaPen as EditIcon,
  FaExclamation as AlertIcon,
} from 'react-icons/fa6'

import { toaster } from '@/components/ui/toaster'
import { useUserPastes, useDeletePasteMutation, useAddToFavoritesMutation } from '../../api/queries'

const UserPastesList = () => {
  const [currentPage, setCurrentPage] = useState(1)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [isOpen, setOpen] = useState(false)
  const { onClose } = useDisclosure()

  const { data: pastesData, isLoading, error, refetch } = useUserPastes(currentPage, 10)
  const deletePasteMutation = useDeletePasteMutation()
  const addToFavoritesMutation = useAddToFavoritesMutation()

  const handleDelete = async () => {
    if (!deleteTarget) return

    try {
      await deletePasteMutation.mutateAsync(deleteTarget.shortCode)
      toaster.create({
        title: 'Paste Deleted',
        description: 'Your paste has been deleted successfully',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })
      onClose()
      setOpen(false)
      setDeleteTarget(null)
    } catch (error) {
      toaster.create({
        title: 'Delete Failed',
        description: error.response?.data?.message || 'Failed to delete paste',
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    }
  }

  const handleAddToFavorites = async (shortCode) => {
    try {
      await addToFavoritesMutation.mutateAsync(shortCode)
      toaster.create({
        title: 'Added to Favorites',
        description: 'Paste has been added to your favorites',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })
    } catch (error) {
      toaster.create({
        title: 'Failed to Add Favorite',
        description: error.response?.data?.message || 'Failed to add to favorites',
        status: 'error',
        duration: 3000,
        isClosable: true,
      })
    }
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    toaster.create({
      title: 'Copied!',
      description: 'Link copied to clipboard',
      status: 'success',
      duration: 2000,
      isClosable: true,
    })
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (isLoading) {
    return (
      <Box maxWidth="1000px" mx="auto" mt={8}>
        <VStack spacing={4} align="stretch">
          <Skeleton height="40px" width="200px" />
          {[...Array(5)].map((_, index) => (
            <Card key={index}>
              <CardBody>
                <HStack spacing={4}>
                  <VStack align="stretch" flex={1}>
                    <Skeleton height="20px" width="300px" />
                    <SkeletonText noOfLines={2} spacing="2" />
                    <Skeleton height="15px" width="150px" />
                  </VStack>
                  <Skeleton height="30px" width="100px" />
                </HStack>
              </CardBody>
            </Card>
          ))}
        </VStack>
      </Box>
    )
  }

  if (error) {
    return (
      <Box maxWidth="1000px" mx="auto" mt={8}>
        <Alert status="error">
          <AlertIcon />
          <Box>
            <Text fontWeight="bold">Failed to load pastes</Text>
            <Text>{error.response?.data?.message || error.message}</Text>
            <Button mt={2} size="sm" onClick={refetch}>
              Try Again
            </Button>
          </Box>
        </Alert>
      </Box>
    )
  }

  const pastes = pastesData?.links || []
  const pagination = pastesData?.pagination || {}
  return (
    <Box maxWidth="1000px" mx="auto" mt={8}>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <Flex align="center">
          <Heading size="lg">My Pastes</Heading>
          <Spacer />
          <Link to="/paste/new">
            <IconButton colorScheme="blue">
              <AddIcon /> Create Paste <span></span>
            </IconButton>
          </Link>
        </Flex>

        {/* Stats */}
        {pagination.total !== undefined && (
          <HStack spacing={4}>
            <Text fontSize="sm" color="gray.600">
              Total: {pagination.total} pastes
            </Text>
            <Text fontSize="sm" color="gray.600">
              Page {pagination.page} of {pagination.pages}
            </Text>
          </HStack>
        )}

        {/* Pastes List */}
        {pastes.length === 0 ? (
          <Card>
            <CardBody textAlign="center" py={8}>
              <Text fontSize="lg" color="gray.500" mb={4}>
                You haven't created any pastes yet
              </Text>
              <Link to="/paste/new">
                <Button leftIcon={<AddIcon />} colorScheme="blue">
                  Create Your First Paste
                </Button>
              </Link>
            </CardBody>
          </Card>
        ) : (
          <VStack spacing={4} align="stretch">
            {pastes.map((paste) => (
              <Card key={paste._id}>
                <CardBody>
                  <HStack spacing={4} align="start">
                    <VStack align="stretch" flex={1} spacing={2}>
                      <HStack justify="space-between" align="start">
                        <VStack align="start" spacing={1}>
                          <Heading size="md">{paste.title || 'Untitled'}</Heading>
                          <HStack spacing={2}>
                            <Badge colorScheme={paste.isPublic ? 'green' : 'orange'} size="sm">
                              {paste.isPublic ? 'Public' : 'Private'}
                            </Badge>
                            {paste.language && (
                              <Badge colorScheme="blue" size="sm">
                                {paste.language}
                              </Badge>
                            )}
                            {paste.isFavorite && (
                              <Badge colorScheme="yellow" size="sm">
                                <StarIcon mr={1} />
                                Favorite
                              </Badge>
                            )}
                          </HStack>
                        </VStack>
                      </HStack>

                      <Text fontSize="sm" color="gray.600" noOfLines={2}>
                        {paste.content || 'No content'}
                      </Text>

                      <HStack spacing={4} fontSize="sm" color="gray.500">
                        <Text>Created: {formatDate(paste.createdAt)}</Text>
                        {paste.updatedAt !== paste.createdAt && <Text>Updated: {formatDate(paste.updatedAt)}</Text>}
                        <Text>Views: {paste.clicks || 0}</Text>
                      </HStack>
                    </VStack>

                    {/* Action Buttons */}
                    <VStack spacing={2}>
                      <HStack spacing={1}>
                        <Tooltip content="View Paste">
                          <Link to={`/paste/${paste.shortCode}`}>
                            <IconButton size="sm" variant="solid">
                              <ViewIcon />
                            </IconButton>
                          </Link>
                        </Tooltip>

                        <Tooltip content="Edit Paste">
                          <Link to={`/paste/${paste.shortCode}/edit`}>
                            <IconButton size="sm" bgColor="darkblue" color="white" variant="solid" colorScheme="white">
                              <EditIcon width="20" height="20" color="white" />
                            </IconButton>
                          </Link>
                        </Tooltip>

                        <Tooltip content="Copy Link">
                          <IconButton
                            size="sm"
                            variant="solid"
                            bgColor=""
                            colorScheme="green"
                            onClick={() => copyToClipboard(`${window.location.origin}/paste/${paste.shortCode}`)}
                          >
                            <CopyIcon color="white" />
                          </IconButton>
                        </Tooltip>

                        {!paste.isFavorite && (
                          <Tooltip content="Add to Favorites">
                            <IconButton
                              size="sm"
                              variant="solid"
                              bgColor="green"
                              colorScheme="yellow"
                              loading={addToFavoritesMutation.isPending}
                              onClick={() => handleAddToFavorites(paste.shortCode)}
                            >
                              <StarIcon size="lg" />
                            </IconButton>
                          </Tooltip>
                        )}

                        <Tooltip content="Delete Paste">
                          <IconButton
                            size="sm"
                            variant="solid"
                            bgColor="red"
                            colorScheme="red"
                            onClick={() => {
                              setDeleteTarget(paste)
                              setOpen(true)
                            }}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      </HStack>

                      <Text fontSize="xs" color="gray.400" fontFamily="mono">
                        {paste.shortCode}
                      </Text>
                    </VStack>
                  </HStack>
                </CardBody>
              </Card>
            ))}
          </VStack>
        )}

        {/* Pagination */}
        {pagination.pages > 1 && (
          <HStack justify="center" spacing={2}>
            <Button
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
              isDisabled={currentPage === 1}
            >
              Previous
            </Button>

            <Text fontSize="sm" px={4}>
              Page {currentPage} of {pagination.pages}
            </Text>

            <Button
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.min(pagination.pages, prev + 1))}
              isDisabled={currentPage === pagination.pages}
            >
              Next
            </Button>
          </HStack>
        )}
      </VStack>

      {/* Delete Confirmation Modal */}
      <Dialog.Root open={isOpen} onOpenChange={(e) => !e.open && onClose()} role="alertdialog">
        <Portal>
          <Dialog.Backdrop />
          <Dialog.Positioner>
            <Dialog.Content>
              <Dialog.Header>
                <Dialog.Title>Delete Paste</Dialog.Title>
              </Dialog.Header>
              <Dialog.CloseTrigger asChild>
                <CloseButton size="sm" />
              </Dialog.CloseTrigger>
              <Dialog.Body>
                <Text>
                  Are you sure you want to delete "{deleteTarget?.title || 'Untitled'}"? This action cannot be undone.
                </Text>
              </Dialog.Body>
              <Dialog.Footer>
                <Dialog.ActionTrigger asChild>
                  <Button variant="ghost" onClick={() => setOpen(false)}>
                    Cancel
                  </Button>
                </Dialog.ActionTrigger>
                <Button colorPalette="red" loading={deletePasteMutation.isPending} onClick={handleDelete}>
                  Delete
                </Button>
              </Dialog.Footer>
            </Dialog.Content>
          </Dialog.Positioner>
        </Portal>
      </Dialog.Root>
    </Box>
  )
}

export default UserPastesList
