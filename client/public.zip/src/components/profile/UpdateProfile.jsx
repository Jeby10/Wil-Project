// File path: src/components/profile/UpdateProfile.jsx
import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import {
  Box,
  Button,
  FieldRoot as FormControl,
  FieldLabel as FormLabel,
  Input,
  VStack,
  Text,
  AlertRoot as Alert,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
  HStack,
  Skeleton,
  SkeletonText,
} from '@chakra-ui/react'
import { FaArrowLeft as ArrowBackIcon, FaExclamation as AlertIcon } from 'react-icons/fa6'
import { useForm } from 'react-hook-form'
import { useProfile, useUpdateProfileMutation } from '../../api/queries'

import { toaster } from '@/components/ui/toaster'

const UpdateProfile = () => {
  const navigate = useNavigate()
  const [serverError, setServerError] = useState('')

  const { data: profileData, isLoading: profileLoading } = useProfile()
  const updateProfileMutation = useUpdateProfileMutation()

  const {
    register,
    handleSubmit,
    formState: { errors, isDirty },
    setValue,
    reset,
  } = useForm()

  // Populate form with current profile data
  useEffect(() => {
    if (profileData?.user) {
      const user = profileData.user
      setValue('username', user.username || '')
      setValue('email', user.email || '')
    }
  }, [profileData, setValue])

  const onSubmit = async (data) => {
    setServerError('')

    try {
      await updateProfileMutation.mutateAsync(data)

      toaster.create({
        title: 'Profile Updated',
        description: 'Your profile has been updated successfully',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })

      navigate('/profile')
      reset(data) // Reset form with new data
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to update profile. Please try again.'
      setServerError(errorMessage)
      toaster.create({
        title: 'Update Failed',
        description: errorMessage,
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    }
  }

  if (profileLoading) {
    return (
      <Box maxWidth="600px" mx="auto" mt={8}>
        <Card>
          <CardHeader>
            <Skeleton height="32px" width="200px" />
          </CardHeader>
          <CardBody>
            <VStack spacing={4} align="stretch">
              <Box>
                <Skeleton height="20px" width="100px" mb={2} />
                <Skeleton height="40px" />
              </Box>
              <Box>
                <Skeleton height="20px" width="100px" mb={2} />
                <Skeleton height="40px" />
              </Box>
              <SkeletonText mt="4" noOfLines={2} spacing="4" />
            </VStack>
          </CardBody>
        </Card>
      </Box>
    )
  }

  return (
    <Box maxWidth="600px" mx="auto" mt={8}>
      <Card>
        <CardHeader>
          <HStack justify="space-between" align="center">
            <Heading size="lg">Update Profile</Heading>
            <Link to="/profile">
              <Button leftIcon={<ArrowBackIcon />} variant="ghost" size="sm">
                Back to Profile
              </Button>
            </Link>
          </HStack>
        </CardHeader>

        <CardBody>
          {serverError && (
            <Alert status="error" mb={4}>
              <AlertIcon />
              {serverError}
            </Alert>
          )}

          <form onSubmit={handleSubmit(onSubmit)}>
            <VStack spacing={4}>
              <FormControl isInvalid={errors.username}>
                <FormLabel>Username</FormLabel>
                <Input
                  type="text"
                  placeholder="Enter your username"
                  {...register('username', {
                    required: 'Username is required',
                    minLength: {
                      value: 3,
                      message: 'Username must be at least 3 characters',
                    },
                    maxLength: {
                      value: 20,
                      message: 'Username must be less than 20 characters',
                    },
                    pattern: {
                      value: /^[a-zA-Z0-9_]+$/,
                      message: 'Username can only contain letters, numbers, and underscores',
                    },
                  })}
                />
                {errors.username && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.username.message}
                  </Text>
                )}
              </FormControl>

              <FormControl isInvalid={errors.email}>
                <FormLabel>Email Address</FormLabel>
                <Input
                  type="email"
                  placeholder="Enter your email"
                  {...register('email', {
                    required: 'Email is required',
                    pattern: {
                      value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                      message: 'Invalid email address',
                    },
                  })}
                />
                {errors.email && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.email.message}
                  </Text>
                )}
              </FormControl>

              <HStack spacing={4} width="100%">
                <Button
                  type="submit"
                  colorScheme="blue"
                  flex={1}
                  loading={updateProfileMutation.isPending}
                  loadingText="Updating..."
                  isDisabled={!isDirty}
                >
                  Update Profile
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  flex={1}
                  onClick={() => navigate('/profile')}
                  isDisabled={updateProfileMutation.isPending}
                >
                  Cancel
                </Button>
              </HStack>

              {!isDirty && (
                <Text fontSize="sm" color="gray.500" textAlign="center">
                  Make changes to enable the update button
                </Text>
              )}
            </VStack>
          </form>
        </CardBody>
      </Card>
    </Box>
  )
}

export default UpdateProfile
