// File path: src/components/profile/ProfileDetail.jsx
import { Link } from 'react-router-dom'
import {
  Box,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
  Text,
  VStack,
  HStack,
  Button,
  Badge,
  Skeleton,
  SkeletonText,
  AlertRoot as Alert,
  Separator,
} from '@chakra-ui/react'
import { FaPencil as EditIcon, FaLock as LockIcon, FaExclamation as AlertIcon } from 'react-icons/fa6'
import { useProfile } from '../../api/queries'

const ProfileDetail = () => {
  const { data: profileData, isLoading, error, refetch } = useProfile()

  if (isLoading) {
    return (
      <Box maxWidth="600px" mx="auto" mt={8}>
        <Card>
          <CardHeader>
            <Skeleton height="32px" width="200px" />
          </CardHeader>
          <CardBody>
            <VStack spacing={4} align="stretch">
              <Box>
                <Skeleton height="20px" width="100px" mb={2} />
                <Skeleton height="40px" />
              </Box>
              <Box>
                <Skeleton height="20px" width="100px" mb={2} />
                <Skeleton height="40px" />
              </Box>
              <Box>
                <Skeleton height="20px" width="100px" mb={2} />
                <Skeleton height="40px" />
              </Box>
              <SkeletonText mt="4" noOfLines={2} spacing="4" />
            </VStack>
          </CardBody>
        </Card>
      </Box>
    )
  }

  if (error) {
    return (
      <Box maxWidth="600px" mx="auto" mt={8}>
        <Alert status="error">
          <AlertIcon />
          <Box>
            <Text fontWeight="bold">Failed to load profile</Text>
            <Text>{error.response?.data?.message || error.message}</Text>
            <Button mt={2} size="sm" onClick={refetch}>
              Try Again
            </Button>
          </Box>
        </Alert>
      </Box>
    )
  }

  const user = profileData?.user

  if (!user) {
    return (
      <Box maxWidth="600px" mx="auto" mt={8}>
        <Alert status="warning">
          <AlertIcon />
          No profile data available
        </Alert>
      </Box>
    )
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  return (
    <Box maxWidth="600px" mx="auto" mt={8}>
      <Card>
        <CardHeader>
          <HStack justify="space-between" align="center">
            <Heading size="lg">Profile Information</Heading>
            <HStack spacing={2}>
              <Link to="/profile/edit">
                <Button leftIcon={<EditIcon />} colorScheme="blue" size="sm">
                  Edit Profile
                </Button>
              </Link>
              <Link to="/profile/password">
                <Button leftIcon={<LockIcon />} variant="outline" size="sm">
                  Change Password
                </Button>
              </Link>
            </HStack>
          </HStack>
        </CardHeader>

        <CardBody>
          <VStack spacing={6} align="stretch">
            {/* Basic Information */}
            <Box>
              <Heading size="md" mb={4}>
                Basic Information
              </Heading>
              <VStack spacing={4} align="stretch">
                <Box>
                  <Text fontSize="sm" fontWeight="bold" color="gray.600" mb={1}>
                    Username
                  </Text>
                  <Text fontSize="lg">{user.username}</Text>
                </Box>

                <Box>
                  <Text fontSize="sm" fontWeight="bold" color="gray.600" mb={1}>
                    Email Address
                  </Text>
                  <HStack>
                    <Text fontSize="lg">{user.email}</Text>
                    {user.emailVerified && (
                      <Badge colorScheme="green" size="sm">
                        Verified
                      </Badge>
                    )}
                  </HStack>
                </Box>

                <Box>
                  <Text fontSize="sm" fontWeight="bold" color="gray.600" mb={1}>
                    User ID
                  </Text>
                  <Text fontSize="sm" fontFamily="mono" color="gray.500">
                    {user.id}
                  </Text>
                </Box>
              </VStack>
            </Box>

            <Separator />

            {/* Account Information */}
            <Box>
              <Heading size="md" mb={4}>
                Account Information
              </Heading>
              <VStack spacing={4} align="stretch">
                <HStack justify="space-between">
                  <Text fontSize="sm" fontWeight="bold" color="gray.600">
                    Account Created
                  </Text>
                  <Text fontSize="sm">{user.createdAt ? formatDate(user.createdAt) : 'Not available'}</Text>
                </HStack>

                <HStack justify="space-between">
                  <Text fontSize="sm" fontWeight="bold" color="gray.600">
                    Last Updated
                  </Text>
                  <Text fontSize="sm">{user.updatedAt ? formatDate(user.updatedAt) : 'Not available'}</Text>
                </HStack>

                <HStack justify="space-between">
                  <Text fontSize="sm" fontWeight="bold" color="gray.600">
                    Account Status
                  </Text>
                  <Badge colorScheme={user.isActive ? 'green' : 'red'} variant="subtle">
                    {user.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </HStack>
              </VStack>
            </Box>

            {/* Statistics */}
            {user.stats && (
              <>
                <Separator />
                <Box>
                  <Heading size="md" mb={4}>
                    Statistics
                  </Heading>
                  <VStack spacing={4} align="stretch">
                    <HStack justify="space-between">
                      <Text fontSize="sm" fontWeight="bold" color="gray.600">
                        Total Pastes
                      </Text>
                      <Badge colorScheme="blue" variant="subtle">
                        {user.stats.totalPastes || 0}
                      </Badge>
                    </HStack>

                    <HStack justify="space-between">
                      <Text fontSize="sm" fontWeight="bold" color="gray.600">
                        Public Pastes
                      </Text>
                      <Badge colorScheme="green" variant="subtle">
                        {user.stats.publicPastes || 0}
                      </Badge>
                    </HStack>

                    <HStack justify="space-between">
                      <Text fontSize="sm" fontWeight="bold" color="gray.600">
                        Private Pastes
                      </Text>
                      <Badge colorScheme="orange" variant="subtle">
                        {user.stats.privatePastes || 0}
                      </Badge>
                    </HStack>

                    <HStack justify="space-between">
                      <Text fontSize="sm" fontWeight="bold" color="gray.600">
                        Favorite Pastes
                      </Text>
                      <Badge colorScheme="purple" variant="subtle">
                        {user.stats.favoritePastes || 0}
                      </Badge>
                    </HStack>
                  </VStack>
                </Box>
              </>
            )}
          </VStack>
        </CardBody>
      </Card>
    </Box>
  )
}

export default ProfileDetail
