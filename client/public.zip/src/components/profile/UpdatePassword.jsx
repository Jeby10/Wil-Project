// File path: src/components/profile/UpdatePassword.jsx
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import {
  Box,
  Button,
  FieldRoot as FormControl,
  FieldLabel as FormLabel,
  Input,
  VStack,
  Text,
  AlertRoot as Alert,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Heading,
  HStack,
} from '@chakra-ui/react'
import { FaArrowLeft as ArrowBackIcon, FaLock as LockIcon, FaExclamation as AlertIcon } from 'react-icons/fa6'
import { useForm } from 'react-hook-form'
import { useUpdatePasswordMutation } from '../../api/queries'

import { toaster } from '@/components/ui/toaster'

const UpdatePassword = () => {
  const navigate = useNavigate()
  const [serverError, setServerError] = useState('')
  const updatePasswordMutation = useUpdatePasswordMutation()

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
  } = useForm()

  const watchNewPassword = watch('newPassword', '')

  const onSubmit = async (data) => {
    setServerError('')

    try {
      await updatePasswordMutation.mutateAsync(data)

      toaster.create({
        title: 'Password Updated',
        description: 'Your password has been updated successfully',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })

      navigate('/profile')
      reset()
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to update password. Please try again.'
      setServerError(errorMessage)
      toaster.create({
        title: 'Update Failed',
        description: errorMessage,
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    }
  }

  return (
    <Box maxWidth="600px" mx="auto" mt={8}>
      <Card>
        <CardHeader>
          <HStack justify="space-between" align="center">
            <Heading size="lg">Change Password</Heading>
            <Link to="/profile">
              <Button leftIcon={<ArrowBackIcon />} variant="ghost" size="sm">
                Back to Profile
              </Button>
            </Link>
          </HStack>
        </CardHeader>

        <CardBody>
          {serverError && (
            <Alert status="error" mb={4}>
              <AlertIcon />
              {serverError}
            </Alert>
          )}

          <Alert status="info" mb={6}>
            <AlertIcon />
            <Box>
              <Text fontWeight="bold">Security Reminder</Text>
              <Text fontSize="sm">
                Choose a strong password with at least 6 characters, including uppercase, lowercase, and numbers.
              </Text>
            </Box>
          </Alert>

          <form onSubmit={handleSubmit(onSubmit)}>
            <VStack spacing={4}>
              <FormControl isInvalid={errors.currentPassword}>
                <FormLabel>Current Password</FormLabel>
                <Input
                  type="password"
                  placeholder="Enter your current password"
                  {...register('currentPassword', {
                    required: 'Current password is required',
                  })}
                />
                {errors.currentPassword && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.currentPassword.message}
                  </Text>
                )}
              </FormControl>

              <FormControl isInvalid={errors.newPassword}>
                <FormLabel>New Password</FormLabel>
                <Input
                  type="password"
                  placeholder="Enter your new password"
                  {...register('newPassword', {
                    required: 'New password is required',
                    minLength: {
                      value: 6,
                      message: 'Password must be at least 6 characters',
                    },
                    pattern: {
                      value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
                      message:
                        'Password must contain at least one uppercase letter, one lowercase letter, and one number',
                    },
                    validate: (value) => {
                      const currentPassword = watch('currentPassword')
                      return value !== currentPassword || 'New password must be different from current password'
                    },
                  })}
                />
                {errors.newPassword && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.newPassword.message}
                  </Text>
                )}
              </FormControl>

              <FormControl isInvalid={errors.confirmPassword}>
                <FormLabel>Confirm New Password</FormLabel>
                <Input
                  type="password"
                  placeholder="Confirm your new password"
                  {...register('confirmPassword', {
                    required: 'Please confirm your new password',
                    validate: (value) => value === watchNewPassword || 'Passwords do not match',
                  })}
                />
                {errors.confirmPassword && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.confirmPassword.message}
                  </Text>
                )}
              </FormControl>

              <HStack spacing={4} width="100%">
                <Button
                  type="submit"
                  colorScheme="blue"
                  leftIcon={<LockIcon />}
                  flex={1}
                  loading={updatePasswordMutation.isPending}
                  loadingText="Updating..."
                >
                  Update Password
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  flex={1}
                  onClick={() => navigate('/profile')}
                  isDisabled={updatePasswordMutation.isPending}
                >
                  Cancel
                </Button>
              </HStack>
            </VStack>
          </form>
        </CardBody>
      </Card>
    </Box>
  )
}

export default UpdatePassword
