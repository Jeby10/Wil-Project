import { createContext, useContext, useEffect, useState } from 'react'
import { authAPI } from '../api/auth.js'
import { useProfile } from '../api/queries.js'

const AuthContext = createContext({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  logout: async () => {},
  register: async () => {},
})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const {
    data: user,
    isLoading: profileLoading,
    // eslint-disable-next-line no-unused-vars
    error: profileError,
    refetch: refetchProfile,
  } = useProfile()

  useEffect(() => {
    const checkAuth = () => {
      const hasToken = authAPI.isAuthenticated()
      setIsAuthenticated(hasToken)
      setIsLoading(false)
    }

    checkAuth()
  }, [])

  const login = async (credentials) => {
    const response = await authAPI.login(credentials)
    setIsAuthenticated(true)
    await refetchProfile()
    return response
  }

  const register = async (userData) => {
    const response = await authAPI.register(userData)
    setIsAuthenticated(true)
    await refetchProfile()
    return response
  }

  const logout = async () => {
    try {
      await authAPI.logout()
      setIsAuthenticated(false)
      return { success: true }
    } catch (error) {
      // Even if logout fails on server, clear local auth
      setIsAuthenticated(false)
      throw error
    }
  }

  const value = {
    user: user?.user || null,
    isAuthenticated,
    isLoading: isLoading || profileLoading,
    login,
    logout,
    register,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
