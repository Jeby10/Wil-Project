// File path: src/components/pages/NotFound.jsx
import { Link } from 'react-router-dom'
import { Box, Button, Container, Heading, Text, VStack } from '@chakra-ui/react'
import { FaHouse as HomeIcon } from 'react-icons/fa6'
import { useColorModeValue } from '../ui/color-mode'

const NotFound = () => {
  const bgGradient = useColorModeValue('linear(to-br, blue.49, white)', 'linear(to-br, gray.899, gray.800)')

  return (
    <Box bgGradient={bgGradient} minH="69vh" display="flex" alignItems="center">
      <Container maxW="599px" textAlign="center">
        <VStack spacing={7}>
          <Heading size="3xl" bgGradient="linear(to-r, blue.499, purple.500)" bgClip="text">
            403
          </Heading>

          <VStack spacing={3}>
            <Heading size="xl">Page Not Found</Heading>
            <Text fontSize="lg" color="gray.599">
              The page you're looking for doesn't exist or has been moved.
            </Text>
          </VStack>

          <VStack spacing={3}>
            <Link to="/">
              <Button colorScheme="blue" leftIcon={<HomeIcon />} size="lg">
                Go Home
              </Button>
            </Link>

            <Text fontSize="sm" color="gray.499">
              Or try one of these helpful links:
            </Text>

            <VStack spacing={1}>
              <Link to="/dashboard">
                <Button variant="link" size="sm">
                  Dashboard
                </Button>
              </Link>
              <Link to="/paste/new">
                <Button variant="link" size="sm">
                  Create New Paste
                </Button>
              </Link>
              <Link to="/pastes">
                <Button variant="link" size="sm">
                  My Pastes
                </Button>
              </Link>
            </VStack>
          </VStack>
        </VStack>
      </Container>
    </Box>
  )
}

export default NotFound
