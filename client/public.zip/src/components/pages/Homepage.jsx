// File path: src/components/pages/HomePage.jsx
import { Link } from 'react-router-dom'
import {
  Box,
  Button,
  Container,
  Heading,
  Text,
  VStack,
  HStack,
  SimpleGrid,
  CardRoot as Card,
  CardBody,
  Icon,
} from '@chakra-ui/react'
import {
  FaPlus as AddIcon,
  FaEye as ViewIcon,
  FaLock as LockIcon,
  FaClock as TimeIcon,
  FaStar as StarIcon,
  FaLink as LinkIcon,
} from 'react-icons/fa6'
import { useAuth } from '../AuthProvider'

import { useColorModeValue } from '../ui/color-mode'

const FeatureCard = ({ icon, title, description }) => {
  const cardBg = useColorModeValue('white', 'gray.700')

  return (
    <Card bg={cardBg} shadow="md">
      <CardBody textAlign="center">
        <VStack spacing={4}>
          <Icon as={icon} w={8} h={8} color="blue.500" />
          <Heading size="md">{title}</Heading>
          <Text color="gray.600" fontSize="sm">
            {description}
          </Text>
        </VStack>
      </CardBody>
    </Card>
  )
}

const HomePage = () => {
  const { isAuthenticated } = useAuth()
  const bgGradient = useColorModeValue('linear(to-br, blue.50, white)', 'linear(to-br, gray.900, gray.800)')

  return (
    <Box>
      {/* Hero Section */}
      <Box bgGradient={bgGradient} py={20}>
        <Container maxW="1200px">
          <VStack spacing={8} textAlign="center">
            <Heading size="2xl" bgGradient="linear(to-r, blue.500, purple.500)" bgClip="text">
              Share Code & Text Instantly
            </Heading>

            <Text fontSize="xl" color="gray.600" maxW="600px">
              The fastest way to share code snippets, text, and collaborate with developers worldwide. Simple, secure,
              and free.
            </Text>

            <HStack spacing={4}>
              {!isAuthenticated ? (
                <>
                  <Link to="/register">
                    <Button colorScheme="blue" size="lg" leftIcon={<AddIcon />}>
                      Get Started Free
                    </Button>
                  </Link>
                  <Link to="/login">
                    <Button variant="outline" size="lg">
                      Sign In
                    </Button>
                  </Link>
                </>
              ) : (
                <>
                  <Link to="/paste/new">
                    <Button colorScheme="blue" size="lg" leftIcon={<AddIcon />}>
                      Create New Paste
                    </Button>
                  </Link>
                  <Link to="/dashboard">
                    <Button variant="outline" size="lg">
                      Go to Dashboard
                    </Button>
                  </Link>
                </>
              )}
            </HStack>

            {/* Quick Stats */}
            <HStack spacing={8} pt={8}>
              <VStack>
                <Text fontSize="2xl" fontWeight="bold" color="blue.500">
                  100k+
                </Text>
                <Text fontSize="sm" color="gray.600">
                  Pastes Created
                </Text>
              </VStack>
              <VStack>
                <Text fontSize="2xl" fontWeight="bold" color="blue.500">
                  50k+
                </Text>
                <Text fontSize="sm" color="gray.600">
                  Active Users
                </Text>
              </VStack>
              <VStack>
                <Text fontSize="2xl" fontWeight="bold" color="blue.500">
                  25+
                </Text>
                <Text fontSize="sm" color="gray.600">
                  Languages Supported
                </Text>
              </VStack>
            </HStack>
          </VStack>
        </Container>
      </Box>

      {/* Features Section */}
      <Container maxW="1200px" py={16}>
        <VStack spacing={12}>
          <VStack spacing={4} textAlign="center">
            <Heading size="xl">Why Choose Our PasteBin?</Heading>
            <Text color="gray.600" maxW="600px">
              Powerful features designed for developers, by developers. Everything you need to share and manage your
              code snippets.
            </Text>
          </VStack>

          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={4} gap={8}>
            <FeatureCard
              icon={ViewIcon}
              title="Syntax Highlighting"
              description="Support for 25+ programming languages with beautiful syntax highlighting for better code readability."
            />

            <FeatureCard
              icon={LockIcon}
              title="Private & Public Pastes"
              description="Keep your sensitive code private or share it publicly. You control who can access your content."
            />

            <FeatureCard
              icon={TimeIcon}
              title="Expiration Control"
              description="Set automatic expiration dates for your pastes. From 1 hour to never expire - you choose."
            />

            <FeatureCard
              icon={StarIcon}
              title="Favorites System"
              description="Save important pastes to your favorites for quick access. Never lose track of important code again."
            />

            <FeatureCard
              icon={LinkIcon}
              title="Short Links"
              description="Get clean, short URLs for easy sharing. Perfect for documentation, emails, and chat messages."
            />

            <FeatureCard
              icon={AddIcon}
              title="Analytics"
              description="Track views, unique visitors, and referrers for your public pastes. Know your impact."
            />
          </SimpleGrid>
        </VStack>
      </Container>

      {/* How It Works Section */}
      <Box bg={useColorModeValue('gray.50', 'gray.800')} py={16}>
        <Container maxW="1200px">
          <VStack spacing={12}>
            <VStack spacing={4} textAlign="center">
              <Heading size="xl">How It Works</Heading>
              <Text color="gray.600" maxW="600px">
                Get started in seconds. No complex setup required.
              </Text>
            </VStack>

            <SimpleGrid columns={{ base: 1, md: 3 }} spacing={8}>
              <VStack spacing={4} textAlign="center">
                <Box
                  w={12}
                  h={12}
                  borderRadius="full"
                  bg="blue.500"
                  color="white"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                  fontSize="xl"
                  fontWeight="bold"
                >
                  1
                </Box>
                <Heading size="md">Paste Your Code</Heading>
                <Text color="gray.600" fontSize="sm">
                  Copy and paste your code or text into our editor. Choose your programming language for syntax
                  highlighting.
                </Text>
              </VStack>

              <VStack spacing={4} textAlign="center">
                <Box
                  w={12}
                  h={12}
                  borderRadius="full"
                  bg="green.500"
                  color="white"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                  fontSize="xl"
                  fontWeight="bold"
                >
                  2
                </Box>
                <Heading size="md">Configure Settings</Heading>
                <Text color="gray.600" fontSize="sm">
                  Set visibility (public/private), expiration date, and add a descriptive title for easy organization.
                </Text>
              </VStack>

              <VStack spacing={4} textAlign="center">
                <Box
                  w={12}
                  h={12}
                  borderRadius="full"
                  bg="purple.500"
                  color="white"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                  fontSize="xl"
                  fontWeight="bold"
                >
                  3
                </Box>
                <Heading size="md">Share & Collaborate</Heading>
                <Text color="gray.600" fontSize="sm">
                  Get a short link to share instantly. Track views and collaborate with your team seamlessly.
                </Text>
              </VStack>
            </SimpleGrid>
          </VStack>
        </Container>
      </Box>

      {/* CTA Section */}
      <Container maxW="1200px" py={16}>
        <VStack spacing={8} textAlign="center">
          <Heading size="xl">Ready to Get Started?</Heading>
          <Text fontSize="lg" color="gray.600" maxW="600px">
            Join thousands of developers who trust our platform for sharing code and collaborating on projects.
          </Text>

          {!isAuthenticated ? (
            <HStack spacing={4}>
              <Link to="/register">
                <Button colorScheme="blue" size="lg">
                  Create Free Account
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" size="lg">
                  Sign In
                </Button>
              </Link>
            </HStack>
          ) : (
            <Link to="/paste/new">
              <Button colorScheme="blue" size="lg" leftIcon={<AddIcon />}>
                Create Your First Paste
              </Button>
            </Link>
          )}
        </VStack>
      </Container>
    </Box>
  )
}

export default HomePage
