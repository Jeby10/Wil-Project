// File path: src/components/pages/Dashboard.jsx
import { Link } from 'react-router-dom'
import {
  Box,
  Button,
  CardRoot as Card,
  CardHeader,
  CardBody,
  Container,
  Heading,
  Text,
  VStack,
  HStack,
  SimpleGrid,
  StatRoot as Stat,
  StatLabel,
  StatValueText as StatNumber,
  StatHelpText,
  Badge,
  Skeleton,
  AlertRoot as Alert,
} from '@chakra-ui/react'

import { FaExclamation as AlertIcon } from 'react-icons/fa6'
import {
  FaPlus as AddIcon,
  FaEye as ViewIcon,
  FaStar as StarIcon,
  FaLock as LockIcon,
  FaClock as TimeIcon,
} from 'react-icons/fa6'
import { useAuth } from '../AuthProvider'
import { useUserPastes, useFavorites } from '../../api/queries'

const QuickStatCard = ({ label, value, helpText, icon, colorScheme = 'blue', isLoading = false }) => {
  return (
    <Stat>
      <StatLabel display="flex" alignItems="center" gap={2}>
        {icon}
        {label}
      </StatLabel>
      {isLoading ? (
        <Skeleton height="32px" width="60px" />
      ) : (
        <StatNumber color={`${colorScheme}.500`}>{value}</StatNumber>
      )}
      <StatHelpText>{helpText}</StatHelpText>
    </Stat>
  )
}

const RecentPasteCard = ({ paste }) => {
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  return (
    <Card size="sm">
      <CardBody>
        <VStack align="stretch" spacing={2}>
          <HStack justify="space-between" align="start">
            <VStack align="start" spacing={1} flex={1}>
              <Text fontWeight="bold" fontSize="sm" noOfLines={1}>
                {paste.title || 'Untitled'}
              </Text>
              <HStack spacing={2}>
                <Badge size="xs" colorScheme={paste.isPublic ? 'green' : 'orange'}>
                  {paste.isPublic ? 'Public' : 'Private'}
                </Badge>
                {paste.language && (
                  <Badge size="xs" colorScheme="blue">
                    {paste.language}
                  </Badge>
                )}
              </HStack>
            </VStack>
          </HStack>

          <Text fontSize="xs" color="gray.600" noOfLines={2}>
            {paste.content}
          </Text>

          <HStack justify="space-between" fontSize="xs" color="gray.500">
            <Text>{formatDate(paste.createdAt)}</Text>
            <Link to={`/paste/${paste.shortCode}`}>
              <Button size="xs" variant="ghost" colorScheme="blue">
                View
              </Button>
            </Link>
          </HStack>
        </VStack>
      </CardBody>
    </Card>
  )
}

const Dashboard = () => {
  const { user } = useAuth()

  const { data: pastesData, isLoading: pastesLoading, error: pastesError } = useUserPastes(1, 5) // Get first 5 pastes for recent activity

  const { data: favoritesData, isLoading: favoritesLoading } = useFavorites(1, 3) // Get first 3 favorites for quick access

  const recentPastes = pastesData?.pastes || []
  const favoritePastes = favoritesData?.favorites || []
  const totalPastes = pastesData?.pagination?.total || 0
  const totalFavorites = favoritesData?.pagination?.total || 0

  // Calculate stats
  const publicPastes = recentPastes.filter((paste) => paste.isPublic).length
  const privatePastes = recentPastes.filter((paste) => !paste.isPublic).length

  return (
    <Container maxW="1200px" py={8}>
      <VStack spacing={8} align="stretch">
        {/* Welcome Header */}
        <Box>
          <Heading size="lg" mb={2}>
            Welcome back, {user?.username}! 👋
          </Heading>
          <Text color="gray.600">Here's what's happening with your pastes today.</Text>
        </Box>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <Heading size="md">Quick Actions</Heading>
          </CardHeader>
          <CardBody>
            <HStack spacing={4} wrap="wrap">
              <Link to="/paste/new">
                <Button colorScheme="blue" leftIcon={<AddIcon />}>
                  Create New Paste
                </Button>
              </Link>
              <Link to="/pastes">
                <Button variant="outline" leftIcon={<ViewIcon />}>
                  View All Pastes
                </Button>
              </Link>
              <Link to="/favorites">
                <Button variant="outline" leftIcon={<StarIcon />}>
                  My Favorites
                </Button>
              </Link>
            </HStack>
          </CardBody>
        </Card>

        {/* Statistics */}
        <Card>
          <CardHeader>
            <Heading size="md">Overview</Heading>
          </CardHeader>
          <CardBody>
            <SimpleGrid columns={{ base: 2, md: 4 }} spacing={6}>
              <QuickStatCard
                label="Total Pastes"
                value={totalPastes}
                helpText="All your pastes"
                icon={<ViewIcon />}
                isLoading={pastesLoading}
              />

              <QuickStatCard
                label="Favorites"
                value={totalFavorites}
                helpText="Saved pastes"
                icon={<StarIcon />}
                colorScheme="yellow"
                isLoading={favoritesLoading}
              />

              <QuickStatCard
                label="Public"
                value={publicPastes}
                helpText="Visible to all"
                icon={<ViewIcon />}
                colorScheme="green"
                isLoading={pastesLoading}
              />

              <QuickStatCard
                label="Private"
                value={privatePastes}
                helpText="Only visible to you"
                icon={<LockIcon />}
                colorScheme="orange"
                isLoading={pastesLoading}
              />
            </SimpleGrid>
          </CardBody>
        </Card>

        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6} gap={2}>
          {/* Recent Pastes */}
          <Card>
            <CardHeader>
              <HStack justify="space-between">
                <Heading size="md">Recent Pastes</Heading>
                <Link to="/pastes">
                  <Button size="sm" variant="ghost">
                    View All
                  </Button>
                </Link>
              </HStack>
            </CardHeader>
            <CardBody>
              {pastesLoading ? (
                <VStack spacing={3}>
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} size="sm" w="full">
                      <CardBody>
                        <VStack spacing={2}>
                          <Skeleton height="16px" width="80%" />
                          <Skeleton height="12px" width="100%" />
                          <Skeleton height="12px" width="60%" />
                        </VStack>
                      </CardBody>
                    </Card>
                  ))}
                </VStack>
              ) : pastesError ? (
                <Alert status="error" size="sm">
                  <AlertIcon />
                  Failed to load recent pastes
                </Alert>
              ) : recentPastes.length === 0 ? (
                <VStack spacing={4} py={8} textAlign="center">
                  <Text color="gray.500">You haven't created any pastes yet</Text>
                  <Link to="/paste/new">
                    <Button colorScheme="blue" size="sm" leftIcon={<AddIcon />}>
                      Create Your First Paste
                    </Button>
                  </Link>
                </VStack>
              ) : (
                <VStack spacing={3} align="stretch">
                  {recentPastes.slice(0, 3).map((paste) => (
                    <RecentPasteCard key={paste.id} paste={paste} />
                  ))}
                </VStack>
              )}
            </CardBody>
          </Card>

          {/* Favorite Pastes */}
          <Card>
            <CardHeader>
              <HStack justify="space-between">
                <Heading size="md">Favorite Pastes</Heading>
                <Link to="/favorites">
                  <Button size="sm" variant="ghost">
                    View All
                  </Button>
                </Link>
              </HStack>
            </CardHeader>
            <CardBody>
              {favoritesLoading ? (
                <VStack spacing={3}>
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} size="sm" w="full">
                      <CardBody>
                        <VStack spacing={2}>
                          <Skeleton height="16px" width="80%" />
                          <Skeleton height="12px" width="100%" />
                          <Skeleton height="12px" width="60%" />
                        </VStack>
                      </CardBody>
                    </Card>
                  ))}
                </VStack>
              ) : favoritePastes.length === 0 ? (
                <VStack spacing={4} py={8} textAlign="center">
                  <Text color="gray.500">No favorite pastes yet</Text>
                  <Text fontSize="sm" color="gray.400">
                    Star your important pastes to see them here
                  </Text>
                </VStack>
              ) : (
                <VStack spacing={3} align="stretch">
                  {favoritePastes.slice(0, 3).map((paste) => (
                    <RecentPasteCard key={paste.id} paste={paste} />
                  ))}
                </VStack>
              )}
            </CardBody>
          </Card>
        </SimpleGrid>

        {/* Tips & Help */}
        <Card>
          <CardHeader>
            <Heading size="md">💡 Tips & Tricks</Heading>
          </CardHeader>
          <CardBody>
            <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
              <VStack align="start" spacing={2}>
                <Text fontWeight="bold" fontSize="sm">
                  🚀 Pro Tips:
                </Text>
                <Text fontSize="sm" color="gray.600">
                  • Use descriptive titles to find your pastes easily
                </Text>
                <Text fontSize="sm" color="gray.600">
                  • Set expiration dates for temporary content
                </Text>
                <Text fontSize="sm" color="gray.600">
                  • Choose the right language for syntax highlighting
                </Text>
              </VStack>

              <VStack align="start" spacing={2}>
                <Text fontWeight="bold" fontSize="sm">
                  🔒 Security:
                </Text>
                <Text fontSize="sm" color="gray.600">
                  • Use private pastes for sensitive information
                </Text>
                <Text fontSize="sm" color="gray.600">
                  • Public pastes are visible to everyone
                </Text>
                <Text fontSize="sm" color="gray.600">
                  • Check expiration settings before sharing
                </Text>
              </VStack>
            </SimpleGrid>
          </CardBody>
        </Card>
      </VStack>
    </Container>
  )
}

export default Dashboard
