// File path: src/components/pages/FavoritePastes.jsx
import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Box,
  Button,
  CardRoot as Card,
  CardBody,
  Heading,
  Text,
  VStack,
  HStack,
  Badge,
  AlertRoot as Alert,
  Skeleton,
  SkeletonText,
  IconButton,
  Container,
} from '@chakra-ui/react'
import { Tooltip } from '@/components/ui/tooltip'
import { FaExclamation as AlertIcon } from 'react-icons/fa6'
import {
  FaEye as ViewIcon,
  FaPencil as EditIcon,
  FaCopy as CopyIcon,
  FaStar as StarIcon,
  FaArrowLeft as ArrowBackIcon,
} from 'react-icons/fa6'
import { useFavorites, useRemoveFromFavoritesMutation } from '../../api/queries'

import { toaster } from '@/components/ui/toaster'

const FavoritePastes = () => {
  const [currentPage, setCurrentPage] = useState(1)

  const { data: favoritesData, isLoading, error, refetch } = useFavorites(currentPage, 10)

  const removeFromFavoritesMutation = useRemoveFromFavoritesMutation()

  const handleRemoveFromFavorites = async (shortCode) => {
    try {
      await removeFromFavoritesMutation.mutateAsync(shortCode)
      toaster.create({
        title: 'Removed from Favorites',
        description: 'Paste has been removed from your favorites',
        status: 'info',
        duration: 3000,
        isClosable: true,
      })
    } catch (error) {
      toaster.create({
        title: 'Failed to Remove',
        description: error.response?.data?.message || 'Failed to remove from favorites',
        status: 'error',
        duration: 3000,
        isClosable: true,
      })
    }
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    toaster.create({
      title: 'Copied!',
      description: 'Link copied to clipboard',
      status: 'success',
      duration: 2000,
      isClosable: true,
    })
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (isLoading) {
    return (
      <Container maxW="1000px" py={8}>
        <VStack spacing={4} align="stretch">
          <Skeleton height="40px" width="200px" />
          {[...Array(5)].map((_, index) => (
            <Card key={index}>
              <CardBody>
                <HStack spacing={4}>
                  <VStack align="stretch" flex={1}>
                    <Skeleton height="20px" width="300px" />
                    <SkeletonText noOfLines={2} spacing="2" />
                    <Skeleton height="15px" width="150px" />
                  </VStack>
                  <Skeleton height="30px" width="100px" />
                </HStack>
              </CardBody>
            </Card>
          ))}
        </VStack>
      </Container>
    )
  }

  if (error) {
    return (
      <Container maxW="1000px" py={8}>
        <Alert status="error">
          <AlertIcon />
          <Box>
            <Text fontWeight="bold">Failed to load favorites</Text>
            <Text>{error.response?.data?.message || error.message}</Text>
            <Button mt={2} size="sm" onClick={refetch}>
              Try Again
            </Button>
          </Box>
        </Alert>
      </Container>
    )
  }

  const favorites = favoritesData?.favorites || []
  const pagination = favoritesData?.pagination || {}

  return (
    <Container maxW="1000px" py={8}>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <HStack justify="space-between" align="center">
          <Heading size="lg">My Favorites</Heading>
          <Link to="/dashboard">
            <Button leftIcon={<ArrowBackIcon />} variant="ghost">
              Back to Dashboard
            </Button>
          </Link>
        </HStack>

        {/* Stats */}
        {pagination.total !== undefined && (
          <HStack spacing={4}>
            <Text fontSize="sm" color="gray.600">
              Total: {pagination.total} favorites
            </Text>
            <Text fontSize="sm" color="gray.600">
              Page {pagination.page} of {pagination.pages}
            </Text>
          </HStack>
        )}

        {/* Favorites List */}
        {favorites.length === 0 ? (
          <Card>
            <CardBody textAlign="center" py={8}>
              <Text fontSize="lg" color="gray.500" mb={4}>
                You haven't favorited any pastes yet
              </Text>
              <Text fontSize="sm" color="gray.400" mb={6}>
                Star pastes you want to keep handy for quick access
              </Text>
              <Link to="/pastes">
                <Button colorScheme="blue">Browse My Pastes</Button>
              </Link>
            </CardBody>
          </Card>
        ) : (
          <VStack spacing={4} align="stretch">
            {favorites.map((paste) => (
              <Card key={paste.id}>
                <CardBody>
                  <HStack spacing={4} align="start">
                    <VStack align="stretch" flex={1} spacing={2}>
                      <HStack justify="space-between" align="start">
                        <VStack align="start" spacing={1}>
                          <Heading size="md">{paste.title || 'Untitled'}</Heading>
                          <HStack spacing={2}>
                            <Badge colorScheme={paste.isPublic ? 'green' : 'orange'} size="sm">
                              {paste.isPublic ? 'Public' : 'Private'}
                            </Badge>
                            {paste.language && (
                              <Badge colorScheme="blue" size="sm">
                                {paste.language}
                              </Badge>
                            )}
                            <Badge colorScheme="yellow" size="sm">
                              <StarIcon mr={1} />
                              Favorite
                            </Badge>
                          </HStack>
                        </VStack>
                      </HStack>

                      <Text fontSize="sm" color="gray.600" noOfLines={2}>
                        {paste.content || 'No content'}
                      </Text>

                      <HStack spacing={4} fontSize="sm" color="gray.500">
                        <Text>Created: {formatDate(paste.createdAt)}</Text>
                        {paste.updatedAt !== paste.createdAt && <Text>Updated: {formatDate(paste.updatedAt)}</Text>}
                        <Text>Views: {paste.views || 0}</Text>
                      </HStack>
                    </VStack>

                    {/* Action Buttons */}
                    <VStack spacing={2}>
                      <HStack spacing={1}>
                        <Tooltip content="View Paste">
                          <Link to={`/paste/${paste.shortCode}`}>
                            <IconButton icon={<ViewIcon />} size="sm" variant="ghost" />
                          </Link>
                        </Tooltip>

                        <Tooltip content="Edit Paste">
                          <Link to={`/paste/${paste.shortCode}/edit`}>
                            <IconButton icon={<EditIcon />} size="sm" variant="ghost" colorScheme="blue" />
                          </Link>
                        </Tooltip>

                        <Tooltip content="Copy Link">
                          <IconButton
                            icon={<CopyIcon />}
                            size="sm"
                            variant="ghost"
                            colorScheme="green"
                            onClick={() => copyToClipboard(`${window.location.origin}/paste/${paste.shortCode}`)}
                          />
                        </Tooltip>

                        <Tooltip content="Remove from Favorites">
                          <IconButton
                            icon={<StarIcon />}
                            size="sm"
                            variant="ghost"
                            colorScheme="red"
                            loading={removeFromFavoritesMutation.isPending}
                            onClick={() => handleRemoveFromFavorites(paste.shortCode)}
                          />
                        </Tooltip>
                      </HStack>

                      <Text fontSize="xs" color="gray.400" fontFamily="mono">
                        {paste.shortCode}
                      </Text>
                    </VStack>
                  </HStack>
                </CardBody>
              </Card>
            ))}
          </VStack>
        )}

        {/* Pagination */}
        {pagination.pages > 1 && (
          <HStack justify="center" spacing={2}>
            <Button
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
              isDisabled={currentPage === 1}
            >
              Previous
            </Button>

            <Text fontSize="sm" px={4}>
              Page {currentPage} of {pagination.pages}
            </Text>

            <Button
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.min(pagination.pages, prev + 1))}
              isDisabled={currentPage === pagination.pages}
            >
              Next
            </Button>
          </HStack>
        )}
      </VStack>
    </Container>
  )
}

export default FavoritePastes
