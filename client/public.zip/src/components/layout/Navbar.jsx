import { Link, useNavigate } from 'react-router-dom'
import {
  Box,
  Flex,
  HStack,
  Button,
  Text,
  Menu,
  AvatarImage as Avatar,
  AvatarRoot,
  Container,
  IconButton,
  useDisclosure,
  VStack,
  Drawer,
  Portal,
  Icon,
} from '@chakra-ui/react'
import {
  FaBars as HamburgerIcon,
  FaChevronDown as ChevronDownIcon,
  FaEye as ViewIcon,
  FaStar as StarIcon,
  FaGear as SettingsIcon,
  FaLock as LockIcon,
  FaRegCircleXmark as CloseButton,
  FaPlus as AddIcon,
} from 'react-icons/fa6'
import { useAuth } from '../AuthProvider'
import { useLogoutMutation } from '../../api/queries'
import { useColorModeValue } from '../ui/color-mode'

import { toaster } from '@/components/ui/toaster'
const Navbar = () => {
  const navigate = useNavigate()
  const { isOpen, onOpen, onClose, setOpen } = useDisclosure()
  const { user, isAuthenticated } = useAuth()
  const logoutMutation = useLogoutMutation()

  const bg = useColorModeValue('white', 'gray.800')
  const borderColor = useColorModeValue('gray.200', 'gray.700')

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync()
      toaster.create({
        title: 'Logged Out',
        description: 'You have been successfully logged out',
        status: 'success',
        duration: 3000,
        isClosable: true,
      })
      navigate('/')
      window.location.reload()
    } catch (error) {
      console.log('NavBar Error', error)
      toaster.create({
        title: 'Logout Error',
        description: 'There was an issue logging out',
        status: 'error',
        duration: 3000,
        isClosable: true,
      })
    }
  }

  const NavLinks = ({ isMobile = false }) => {
    if (!isAuthenticated) {
      return (
        <HStack spacing={4} direction={isMobile ? 'column' : 'row'}>
          <Link to="/login" onClick={(e) => e.bubbles()}>
            <Button variant="ghost" size="sm" onClick={setOpen(false)}>
              Login
            </Button>
          </Link>
          <Link to="/register" onClick={(e) => e.bubbles()}>
            <Button colorScheme="blue" size="sm" onClick={setOpen(false)}>
              Sign Up
            </Button>
          </Link>
        </HStack>
      )
    }

    if (isMobile) {
      return (
        <VStack spacing={4} align="stretch">
          <Link to="/dashboard">
            <Button variant="ghost" w="full" justifyContent="start">
              Dashboard
            </Button>
          </Link>
          <Link to="/paste/new">
            <Button colorScheme="blue" leftIcon={<AddIcon />} w="full">
              Create Paste
            </Button>
          </Link>
          <Link to="/pastes">
            <Button variant="ghost" leftIcon={<ViewIcon />} w="full" justifyContent="start">
              My Pastes
            </Button>
          </Link>
          <Link to="/favorites">
            <Button variant="ghost" leftIcon={<StarIcon />} w="full" justifyContent="start">
              Favorites
            </Button>
          </Link>
          {/* <Menu.Separator /> */}
          <Link to="/profile">
            <Button variant="ghost" leftIcon={<SettingsIcon />} w="full" justifyContent="start">
              Profile
            </Button>
          </Link>
          <Button
            variant="ghost"
            w="auto"
            outline={false}
            justifyContent="start"
            onClick={handleLogout}
            loading={logoutMutation.isPending}
          >
            Logout
          </Button>
        </VStack>
      )
    }

    return (
      <HStack spacing={4}>
        <Link to="/paste/new">
          <Button colorScheme="blue" leftIcon={<AddIcon />} size="sm">
            Create
          </Button>
        </Link>

        <Menu.Root navigate={({ value }) => navigate(`/${value}`)}>
          <Menu.Trigger asChild>
            <Button rightIcon={<ChevronDownIcon />} variant="ghost" size="sm">
              <HStack spacing={2}>
                <AvatarRoot>
                  <Avatar size="xs" name={user?.username || 'User'} />
                </AvatarRoot>
                <Text>{user?.username || 'User'}</Text>
              </HStack>
            </Button>
          </Menu.Trigger>
          <Portal>
            <Menu.Positioner>
              <Menu.Content>
                <Menu.Item asChild value="dashboard">
                  <Link to="/dashboard">Dashboard</Link>
                </Menu.Item>
                <Menu.Item asChild value="pastes">
                  <Link to="/pastes">
                    <ViewIcon />
                    My Pastes
                  </Link>
                </Menu.Item>
                <Menu.Item asChild value="favorites">
                  <Link to="/favorites">
                    <StarIcon />
                    Favorites
                  </Link>
                </Menu.Item>
                <Menu.Separator />
                <Menu.Item asChild value="profile">
                  <Link to="/profile">
                    <SettingsIcon />
                    Profile Settings
                  </Link>
                </Menu.Item>
                <Menu.Item asChild value="profile/password">
                  <Link to="/profile/password">
                    <LockIcon />
                    Change Password
                  </Link>
                </Menu.Item>
                <Menu.Separator />
                <Menu.Item value="logout" onSelect={handleLogout} color="red.500" disabled={logoutMutation.isPending}>
                  {logoutMutation.isPending ? 'Logging out...' : 'Logout'}
                </Menu.Item>
              </Menu.Content>
            </Menu.Positioner>
          </Portal>
        </Menu.Root>
      </HStack>
    )
  }

  return (
    <Box bg={bg} borderBottom="1px" borderColor={borderColor}>
      <Container maxW="1200px">
        <Flex h={16} alignItems="center" justifyContent="space-between">
          {/* Logo */}
          <Link to="/">
            <Text fontSize="xl" fontWeight="bold" color="blue.500">
              PasteBin
            </Text>
          </Link>

          {/* Desktop Navigation */}
          <HStack spacing={8} display={{ base: 'none', md: 'flex' }}>
            <NavLinks />
          </HStack>

          {/* Mobile Navigation Drawer */}

          <Drawer.Root open={isOpen} onOpenChange={(e) => (e.open ? onOpen() : onClose())} placement="end">
            <Drawer.Trigger asChild>
              <IconButton size="md" aria-label="Open menu" display={{ base: 'flex', md: 'none' }}>
                <HamburgerIcon />
              </IconButton>
            </Drawer.Trigger>
            <Portal>
              <Drawer.Backdrop />
              <Drawer.Positioner>
                <Drawer.Content>
                  <Drawer.Header>
                    <Drawer.Title>
                      <Text fontSize="lg" fontWeight="bold" color="blue.500">
                        PasteBin
                      </Text>
                    </Drawer.Title>
                  </Drawer.Header>
                  <Drawer.Body>
                    <NavLinks isMobile />
                  </Drawer.Body>
                  <Drawer.CloseTrigger asChild>
                    <Icon>
                      <CloseButton />
                    </Icon>
                  </Drawer.CloseTrigger>
                </Drawer.Content>
              </Drawer.Positioner>
            </Portal>
          </Drawer.Root>
        </Flex>
      </Container>
    </Box>
  )
}

export default Navbar
