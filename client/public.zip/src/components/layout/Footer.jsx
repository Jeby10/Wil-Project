// File path: src/components/layout/Footer.jsx
import { Box, Container, Text, HStack, VStack, Link as ChakraLink, Separator } from '@chakra-ui/react'

import { useColorModeValue } from '../ui/color-mode'
import { Link } from 'react-router-dom'

const Footer = () => {
  const bg = useColorModeValue('gray.50', 'gray.900')
  const borderColor = useColorModeValue('gray.200', 'gray.700')
  const textColor = useColorModeValue('gray.600', 'gray.400')

  return (
    <Box bg={bg} borderTop="1px" borderColor={borderColor} mt="auto">
      <Container maxW="1200px" py={8}>
        <VStack spacing={6}>
          {/* Main Footer Content */}
          <HStack spacing={8} wrap="wrap" justify="center" divider={<Text color={textColor}>•</Text>}>
            {/* <Link to="/"> */}
            <ChakraLink to="/" color={textColor} fontSize="sm" _hover={{ color: 'blue.500' }}>
              Home
            </ChakraLink>
            {/* </Link> */}

            <ChakraLink href="/about" color={textColor} fontSize="sm" _hover={{ color: 'blue.500' }}>
              About
            </ChakraLink>

            <ChakraLink href="/privacy" color={textColor} fontSize="sm" _hover={{ color: 'blue.500' }}>
              Privacy Policy
            </ChakraLink>

            <ChakraLink href="/terms" color={textColor} fontSize="sm" _hover={{ color: 'blue.500' }}>
              Terms of Service
            </ChakraLink>

            <ChakraLink href="/contact" color={textColor} fontSize="sm" _hover={{ color: 'blue.500' }}>
              Contact
            </ChakraLink>
          </HStack>

          <Separator />

          {/* Copyright */}
          <VStack spacing={2}>
            <Text fontSize="sm" color={textColor} textAlign="center">
              © {new Date().getFullYear()} PasteBin. All rights reserved.
            </Text>
            <Text fontSize="xs" color={textColor} textAlign="center">
              Share code, text, and snippets with the world.
            </Text>
          </VStack>
        </VStack>
      </Container>
    </Box>
  )
}

export default Footer
