// File path: src/App.jsx
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'

import { useColorMode } from './components/ui/color-mode'
// Context Providers
import { AuthProvider, useAuth } from './components/AuthProvider'

// Layout Components
import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'

// Auth Components
import LoginForm from './components/auth/LoginForm'
import RegisterForm from './components/auth/RegisterForm'

// Profile Components
import ProfileDetail from './components/profile/ProfileDetail'
import UpdateProfile from './components/profile/UpdateProfile'
import UpdatePassword from './components/profile/UpdatePassword'

// Paste Components
import CreatePaste from './components/pastes/CreatePaste'
import UserPastesList from './components/pastes/UserPastesList'
import PasteDetails from './components/pastes/PasteDetails'
import PublicPasteView from './components/pastes/PublicPasteView'
import EditPaste from './components/pastes/EditPaste'

// Page Components
import HomePage from './components/pages/Homepage'
import Dashboard from './components/pages/Dashboard'
import FavoritePastes from './components/pages/FavoritePastes'
import NotFound from './components/pages/NotFound'
import { Box, Container, Skeleton, SkeletonText, Stack, HStack } from '@chakra-ui/react'

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    return (
      <Box py={16}>
        <Container maxW="1200px">
          <Stack gap="6" width="full">
            {/* 1. Text box - width full, height minimum 2 lines */}
            <SkeletonText noOfLines={2} gap="2" loading={isLoading} />

            {/* 2. Big Box - width full, height minimum 10 lines */}
            <Skeleton
              width="full"
              height="240px" // Approximately 10 lines height
              loading={isLoading}
            />

            {/* 3. Two Horizontal Skeletons - height of 2 lines each */}
            <HStack gap="4" width="full">
              <Skeleton
                flex="1"
                height="48px" // Approximately 2 lines height
                loading={isLoading}
              />
              <Skeleton
                flex="1"
                height="48px" // Approximately 2 lines height
                loading={isLoading}
              />
            </HStack>
          </Stack>
        </Container>
      </Box>
    )
  }

  return isAuthenticated ? children : <Navigate to="/login" replace />
}

// Public Only Route Component (redirect if already authenticated)
const PublicOnlyRoute = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    return <div>Loading...</div>
  }

  return !isAuthenticated ? children : <Navigate to="/dashboard" replace />
}

// Layout Component with Navbar and Footer
const Layout = ({ children }) => {
  return (
    <>
      <Navbar />
      <main style={{ minHeight: 'calc(100vh - 120px)' }}>{children}</main>
      <Footer />
    </>
  )
}

// App Component
const App = () => {
  useColorMode()

  return (
    <>
      {/* <Router> */}
      <AuthProvider>
        <Layout>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<HomePage />} />
            <Route path="/paste/:shortCode" element={<PublicPasteView />} />

            {/* Authentication Routes (Public Only) */}
            <Route
              path="/login"
              element={
                <PublicOnlyRoute>
                  <LoginForm />
                </PublicOnlyRoute>
              }
            />
            <Route
              path="/register"
              element={
                <PublicOnlyRoute>
                  <RegisterForm />
                </PublicOnlyRoute>
              }
            />

            {/* Protected Routes */}
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />

            {/* Profile Routes */}
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <ProfileDetail />
                </ProtectedRoute>
              }
            />
            <Route
              path="/profile/edit"
              element={
                <ProtectedRoute>
                  <UpdateProfile />
                </ProtectedRoute>
              }
            />
            <Route
              path="/profile/password"
              element={
                <ProtectedRoute>
                  <UpdatePassword />
                </ProtectedRoute>
              }
            />

            {/* Paste Management Routes */}
            <Route
              path="/paste/new"
              element={
                <ProtectedRoute>
                  <CreatePaste />
                </ProtectedRoute>
              }
            />
            <Route
              path="/pastes"
              element={
                <ProtectedRoute>
                  <UserPastesList />
                </ProtectedRoute>
              }
            />
            <Route
              path="/paste/:shortCode/details"
              element={
                <ProtectedRoute>
                  <PasteDetails />
                </ProtectedRoute>
              }
            />
            <Route
              path="/paste/:shortCode/edit"
              element={
                <ProtectedRoute>
                  <EditPaste />
                </ProtectedRoute>
              }
            />

            {/* Favorites Route */}
            <Route
              path="/favorites"
              element={
                <ProtectedRoute>
                  <FavoritePastes />
                </ProtectedRoute>
              }
            />

            {/* Redirect /paste/:shortCode/details to authenticated view for logged in users */}
            <Route path="/paste/:shortCode" element={<PublicPasteView />} />

            {/* Catch-all route for 404 */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Layout>
      </AuthProvider>
      {/* </Router> */}
    </>
  )
}

export default App
