// File path: src/api/paste.js
import { apiClient } from './client.js'

export const pasteAPI = {
  // Create new paste
  createPaste: async (pasteData) => {
    const response = await apiClient.post('/api/links', pasteData)
    return response.data
  },

  // Get user's pastes with pagination
  getUserPastes: async (page = 1, limit = 10) => {
    const response = await apiClient.get('/api/links', {
      params: { page, limit },
    })
    return response.data
  },

  // Get paste by short code (authenticated)
  getPasteByCode: async (shortCode) => {
    const response = await apiClient.get(`/api/links/${shortCode}`)
    return response.data
  },

  // Get public paste by short code (no auth required)
  getPublicPaste: async (shortCode) => {
    // Create a new axios instance without auth interceptors for public requests
    const { default: axios } = await import('axios')
    const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000'

    const response = await axios.get(`${API_BASE_URL}/paste/${shortCode}`, {
      headers: {
        'Content-Type': 'application/json',
      },
    })
    return response.data
  },

  // Update paste
  updatePaste: async (shortCode, updateData) => {
    const response = await apiClient.put(`/api/links/${shortCode}`, updateData)
    return response.data
  },

  // Delete paste
  deletePaste: async (shortCode) => {
    const response = await apiClient.delete(`/api/links/${shortCode}`)
    return response.data
  },

  // Get paste analytics
  getPasteAnalytics: async (shortCode) => {
    const response = await apiClient.get(`/api/links/${shortCode}/analytics`)
    return response.data
  },

  // Add paste to favorites
  addToFavorites: async (shortCode) => {
    const response = await apiClient.post(`/api/links/favorites/${shortCode}`)
    return response.data
  },

  // Remove paste from favorites
  removeFromFavorites: async (shortCode) => {
    const response = await apiClient.delete(`/api/links/favorites/${shortCode}`)
    return response.data
  },

  // Get user's favorite pastes
  getFavorites: async (page = 1, limit = 10) => {
    const response = await apiClient.get('/api/links/me/favorites', {
      params: { page, limit },
    })
    return response.data
  },

  // Get paste statistics for dashboard
  getPasteStats: async () => {
    const response = await apiClient.get('/api/links/stats')
    return response.data
  },

  // Search pastes (if implemented on backend)
  searchPastes: async (query, page = 1, limit = 10) => {
    const response = await apiClient.get('/api/links/search', {
      params: { q: query, page, limit },
    })
    return response.data
  },

  // Get pastes by language filter
  getPastesByLanguage: async (language, page = 1, limit = 10) => {
    const response = await apiClient.get('/api/links', {
      params: { language, page, limit },
    })
    return response.data
  },

  // Bulk delete pastes
  bulkDeletePastes: async (shortCodes) => {
    const response = await apiClient.post('/api/links/bulk-delete', {
      shortCodes,
    })
    return response.data
  },

  // Clone/fork paste (create copy)
  clonePaste: async (shortCode, newData = {}) => {
    const response = await apiClient.post(`/api/links/${shortCode}/clone`, newData)
    return response.data
  },

  // Report paste (for moderation)
  reportPaste: async (shortCode, reason) => {
    const response = await apiClient.post(`/api/links/${shortCode}/report`, {
      reason,
    })
    return response.data
  },

  // Get trending/popular pastes (public)
  getTrendingPastes: async (timeframe = '24h', limit = 10) => {
    const { default: axios } = await import('axios')
    const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000'

    const response = await axios.get(`${API_BASE_URL}/api/pastes/trending`, {
      params: { timeframe, limit },
      headers: {
        'Content-Type': 'application/json',
      },
    })
    return response.data
  },

  // Get recent public pastes
  getRecentPublicPastes: async (limit = 10) => {
    const { default: axios } = await import('axios')
    const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000'

    const response = await axios.get(`${API_BASE_URL}/api/pastes/recent`, {
      params: { limit },
      headers: {
        'Content-Type': 'application/json',
      },
    })
    return response.data
  },
}
