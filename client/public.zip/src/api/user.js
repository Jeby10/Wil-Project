// src/api/user.js
import { apiClient } from './client.js'

export const userAPI = {
  // Update user profile
  updateProfile: async (profileData) => {
    const response = await apiClient.put('/api/user/profile', profileData)
    return response.data
  },

  // Update user password
  updatePassword: async (passwordData) => {
    const response = await apiClient.put('/api/user/password', passwordData)
    return response.data
  },
}
