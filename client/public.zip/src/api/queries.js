// src/api/queries.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { authAPI } from './auth.js'
import { pasteAPI } from './paste.js'
import { userAPI } from './user.js'
// import { healthAPI } from './health.js';

// Query keys
export const queryKeys = {
  user: ['user'],
  userProfile: ['user', 'profile'],
  pastes: ['pastes'],
  userPastes: (page, limit) => ['pastes', 'user', { page, limit }],
  paste: (shortCode) => ['paste', shortCode],
  publicPaste: (shortCode) => ['publicPaste', shortCode],
  favorites: (page, limit) => ['favorites', { page, limit }],
  analytics: (shortCode) => ['analytics', shortCode],
  // health: ['health'],
}

// Auth Queries
export const useProfile = () => {
  return useQuery({
    queryKey: queryKeys.userProfile,
    queryFn: authAPI.getProfile,
    enabled: authAPI.isAuthenticated(),
    staleTime: 5 * 60 * 1000, // 5 minutes
  })
}

export const useLoginMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: authAPI.login,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.userProfile })
    },
  })
}

export const useRegisterMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: authAPI.register,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.userProfile })
    },
  })
}

export const useLogoutMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: authAPI.logout,
    onSuccess: () => {
      queryClient.clear()
    },
  })
}

// Paste Queries
export const useUserPastes = (page = 1, limit = 10) => {
  return useQuery({
    queryKey: queryKeys.userPastes(page, limit),
    queryFn: () => pasteAPI.getUserPastes(page, limit),
    enabled: authAPI.isAuthenticated(),
    staleTime: 2 * 60 * 1000, // 2 minutes
  })
}

export const usePaste = (shortCode) => {
  return useQuery({
    queryKey: queryKeys.paste(shortCode),
    queryFn: () => pasteAPI.getPasteByCode(shortCode),
    enabled: !!shortCode && authAPI.isAuthenticated(),
    staleTime: 5 * 60 * 1000,
  })
}

export const usePublicPaste = (shortCode) => {
  return useQuery({
    queryKey: queryKeys.publicPaste(shortCode),
    queryFn: () => pasteAPI.getPublicPaste(shortCode),
    enabled: !!shortCode,
    staleTime: 5 * 60 * 1000,
  })
}

export const useCreatePasteMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: pasteAPI.createPaste,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.pastes })
    },
  })
}

export const useUpdatePasteMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ shortCode, data }) => pasteAPI.updatePaste(shortCode, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.paste(variables.shortCode) })
      queryClient.invalidateQueries({ queryKey: queryKeys.pastes })
    },
  })
}

export const useDeletePasteMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: pasteAPI.deletePaste,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.pastes })
    },
  })
}

// Favorites Queries
export const useFavorites = (page = 1, limit = 10) => {
  return useQuery({
    queryKey: queryKeys.favorites(page, limit),
    queryFn: () => pasteAPI.getFavorites(page, limit),
    enabled: authAPI.isAuthenticated(),
    staleTime: 2 * 60 * 1000,
  })
}

export const useAddToFavoritesMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: pasteAPI.addToFavorites,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favorites'] })
    },
  })
}

export const useRemoveFromFavoritesMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: pasteAPI.removeFromFavorites,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favorites'] })
    },
  })
}

// Analytics Query
export const usePasteAnalytics = (shortCode) => {
  return useQuery({
    queryKey: queryKeys.analytics(shortCode),
    queryFn: () => pasteAPI.getPasteAnalytics(shortCode),
    enabled: !!shortCode && authAPI.isAuthenticated(),
    staleTime: 30 * 1000, // 30 seconds for analytics
  })
}

// User Management Mutations
export const useUpdateProfileMutation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: userAPI.updateProfile,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.userProfile })
    },
  })
}

export const useUpdatePasswordMutation = () => {
  return useMutation({
    mutationFn: userAPI.updatePassword,
  })
}

// Health Check Query
export const useHealthCheck = () => {
  return useQuery({
    queryKey: ['health'],
    // queryFn: healthAPI.checkHealth,
    staleTime: 30 * 1000, // 30 seconds
    retry: 1,
  })
}
